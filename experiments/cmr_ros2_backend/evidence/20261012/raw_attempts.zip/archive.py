"""Archive original failure plus assertion-only replay; standard library only."""
import hashlib,json,pathlib,shutil,zipfile
repo=pathlib.Path('D:/Robotics/Robotics4LLM/ltl_automaton_core-ros2')
raw=pathlib.Path('//wsl.localhost/Ubuntu-22.04-D/tmp/cmr_unified_ed015fe_20261012')
folder=repo/'experiments/cmr_ros2_backend'
evidence=folder/'evidence/20261012'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
r=read(raw/'native_readback.json')
assert r['status']=='PASSED' and r['independent_feasible_certificate_replays']==19
for name,code in [('fixtures.rc','0'),('run.rc','1'),('wsl.rc','1'),('validation.rc','0'),('validation_wsl.rc','0'),('native_reader.rc','0')]:
    assert (raw/name).read_text().strip()==code,name
for name in ['readback.py','validate_recorded.py','dds.py']:
    target=raw/'validated_sources'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(folder/name,target)
shutil.copyfile(repo/'experiments/cmr_ros2_product_perf/native_readback.py',raw/'validated_sources/native_helpers.py')
shutil.copyfile('C:/Users/Yuhling/AppData/Local/Temp/cmr_unified_exec.sh',raw/'exec.sh')
shutil.copyfile('C:/Users/Yuhling/AppData/Local/Temp/cmr_unified_validate.sh',raw/'validate.sh')
shutil.copyfile(__file__,raw/'archive.py')
shutil.copyfile(raw/'backend_binding.json',folder/'backend_binding.json')
evidence.mkdir(parents=True,exist_ok=False)
(evidence/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n')
paths=sorted(p for p in raw.rglob('*') if p.is_file())
manifest={p.relative_to(raw).as_posix():{'size':p.stat().st_size,'sha256':sha(p)} for p in paths}
archive=evidence/'raw_attempts.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,p.relative_to(raw).as_posix())
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(manifest)
    for name,expected in manifest.items():
        data=z.read(name)
        assert len(data)==expected['size'] and hashlib.sha256(data).hexdigest()==expected['sha256'],name
write(evidence/'archive_manifest.json',dict(schema='cmr-unified-archive-manifest-v1',members=manifest))
shutil.copyfile(raw/'native_readback.json',evidence/'native_readback.json')
shutil.copyfile(raw/'validation_correction.json',evidence/'validation_correction.json')
plan=read(raw/'plan.json')
index=dict(schema='cmr-unified-evidence-index-v1',status='PASSED',scope=plan['scope'],
    source_head=plan['source_head'],execution_identity=plan['execution_identity'],
    version_binding_id=r['version_binding_id'],version_binding_sha256=r['version_binding_sha256'],
    instances=[p['instance_id'] for p in plan['records']],cells=plan['cells'],
    backends=plan['backends'],attempts_per_cell_backend=1,method_workers=24,dds_workers=2,
    independent_feasible_certificate_replays=19,exact_empty_outcomes=7,total_build_rounds=r['total_build_rounds'],
    frozen_inputs=58,offline_checks=16,planner_budget_seconds=180,outer_watchdog_seconds=195,
    formal_campaign=False,provider_calls=0,dds_runs=2,original_driver_rc=1,original_wsl_rc=1,
    original_qualification_status='FAILED',assertion_replay_rc=0,assertion_replay_wsl_rc=0,native_reader_rc=0,
    additional_solver_workers=0,additional_dds_runs=0,archive_members=len(manifest),notes=[
      'One selectable reference/ros2-v6 frontend; separate canonical source/algorithm/authority version binding. V6 algorithm and original science files remain qualified bytes.',
      'Three old anchors and three metadata-only extensions, 12 paired cells/24 workers, plus exactly two actual DDS V6 worker requests. No retries or formal ledger writes.',
      'All 26 workers and four DDS nodes exit0. 19 feasible persisted certificates independently replay PASS. Seven original exact-empty outcomes have no feasible-lasso certificate or execution payload; do not count them as independent certificate replays.',
      'Original DDS success was falsely rejected because validator disallowed deliberate stale generation0 reception. Original FAILED reports/driver and WSL rc1 remain. Corrected assertion-only replay requires unique stale injection after generation1 authority, current step progression and no extra dispatch.',
      'Only _validate_case AST changes; transport, backend, workers and all other executed source bytes remain. Supplemental validation uses original raw records and pending certificate replay, zero new solver/DDS execution.',
      'DDS success executes full three-step prefix and one-step closed suffix with independent TS feedback; infeasible case publishes result with zero dispatch/feedback/snapshot.',
      'Original INITIAL_LABEL_V1, Fraction/gamma10, full rebuild/refinement, 180/195 budgets, P2c/P2e/verifier and right-censoring/terminal delivery retained.',
      'Current default production planner, frozen formal CMR solver/170x3 campaign and old qualifications unchanged; no providers, physical robot, or historical136/754 test reruns.'])
index['files']={p.name:{'size':p.stat().st_size,'sha256':sha(p)} for p in [archive,evidence/'archive_manifest.json',evidence/'native_readback.json',evidence/'validation_correction.json']}
write(evidence/'index.json',index)
print(json.dumps({'archive':index['files']['raw_attempts.zip'],'members':len(manifest),'binding':r['version_binding_id'],'rounds':r['total_build_rounds']}))
