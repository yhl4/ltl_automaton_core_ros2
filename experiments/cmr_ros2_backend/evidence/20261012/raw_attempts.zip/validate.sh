#!/usr/bin/env bash
set -e
cd /mnt/d/Robotics/Robotics4LLM/ltl_automaton_core-ros2
source /opt/ros/humble/setup.bash
source /tmp/ltl_ros2_combo_bd75495/install/setup.bash
export PYTHONDONTWRITEBYTECODE=1
output=/tmp/cmr_unified_ed015fe_20261012
receipt=/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json
kernel=/mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel
set +e
python3 -B experiments/cmr_ros2_backend/validate_recorded.py --output "$output" --binding "$receipt" --kernel-root "$kernel" > "$output/validation.stdout.txt" 2> "$output/validation.stderr.txt"
validation_rc=$?
printf '%s\n' "$validation_rc" > "$output/validation.rc"
exit "$validation_rc"
