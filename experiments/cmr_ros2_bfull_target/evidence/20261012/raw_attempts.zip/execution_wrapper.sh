#!/usr/bin/env bash
set -e
cd /mnt/d/Robotics/Robotics4LLM/ltl_automaton_core-ros2
source /opt/ros/humble/setup.bash
source /tmp/ltl_ros2_combo_bd75495/install/setup.bash
export PYTHONDONTWRITEBYTECODE=1
receipt=/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json
kernel=/mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel
output=/tmp/cmr_bfull_target_a58fce3_20261012
python3 -B experiments/cmr_ros2_bfull_target/compare.py --prepare --binding "$receipt" --kernel-root "$kernel" --output "$output"
set +e
python3 -B experiments/cmr_ros2_bfull_target/fixtures.py --output "$output/fixtures.json"
fixture_rc=$?
printf '%s\n' "$fixture_rc" > "$output/fixtures.rc"
if [ "$fixture_rc" -ne 0 ]; then exit "$fixture_rc"; fi
python3 -B experiments/cmr_ros2_bfull_target/compare.py --binding "$receipt" --kernel-root "$kernel" --output "$output" > "$output/stdout.txt" 2> "$output/stderr.txt"
run_rc=$?
printf '%s\n' "$run_rc" > "$output/run.rc"
exit "$run_rc"