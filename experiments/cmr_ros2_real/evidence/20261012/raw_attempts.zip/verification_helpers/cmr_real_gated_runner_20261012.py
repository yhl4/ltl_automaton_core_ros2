def main():
    import ast
    import hashlib
    import json
    import os
    from pathlib import Path
    import platform
    import shutil
    import subprocess
    import sys
    import time
    import traceback
    repo = Path('/mnt/d/Robotics/Robotics4LLM/ltl_automaton_core-ros2')
    work = Path('/tmp/ltl_cmr_ros2_real_6778dcb_20261012')
    work.mkdir(exist_ok=False)
    sys.path.insert(0,str(repo/'experiments/cmr_ros2_real'))
    import runner as adapter
    from bound_runner import load_bound_runner
    binding_arg = '/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json'
    kernel = '/mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel'
    head = subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
    assert head == '6778dcb5390203fb90651fe8b725293a5f7de363'
    selection = adapter.load_selection()
    receipt_path = Path(binding_arg)
    receipt = json.loads(receipt_path.read_text())
    bound_path = adapter.runtime.core_smoke._native_path(receipt['execution_binding']['path'])
    binding = json.loads(bound_path.read_text())
    def info(path):
        raw = Path(path).read_bytes()
        return dict(size=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    original = json.loads(Path('/tmp/ltl_replan_type_tuple_regression_fa9c990/expected_inputs.json').read_text())
    for path,expected in original.items():
        assert info(path) == expected,path
    paths = list(original)
    paths += [str(path) for path in sorted((repo/'experiments/cmr_ros2_real').glob('*')) if path.is_file()]
    paths += [str(repo/'experiments/cmr_ros2_smoke'/name) for name in ('smoke.py','backend.py','README.md')]
    paths += [str(repo/'experiments/cmr_ros2_integration'/name) for name in ('runtime.py','verify_smoke.py','dds_smoke.py','README.md')]
    paths += [str(adapter.runtime.core_smoke._native_path(row['path'])) for row in binding['scientific_sources'].values()]
    paths += [str(receipt_path),str(bound_path),str(adapter.runtime.core_smoke._native_path(binding['manifest_path']))]
    paths += [str(adapter.runtime.core_smoke._native_path(binding['benchmark_root'])/r['path']) for r in selection['records']]
    paths += [str(repo/'ltl_automaton_execution/ltl_automaton_execution'/name) for name in ('execution_node.py','execution.py','fake_runtime.py','models.py','accepted_run_resolver.py')]
    before = {path:info(path) for path in paths}
    frozen = work/'frozen_adapter'
    frozen.mkdir()
    for path in sorted((repo/'experiments/cmr_ros2_real').glob('*')):
        if path.is_file():
            shutil.copyfile(path,frozen/path.name)
    metadata = dict(schema='cmr-ros2-real-gated-runner-v1',head=head,scope='CORE_SUBSET_QUALIFICATION',before=before,start_ns=time.time_ns(),python=platform.python_version(),qualification_rc=None,preflight_rc=None,formal_campaign=False)
    adapter.runtime.write_json(work/'runner.json',metadata)
    code = 1
    try:
        for path in sorted((repo/'experiments/cmr_ros2_real').glob('*.py')):
            ast.parse(path.read_bytes(),filename=str(path))
        formal,bound,manifest = load_bound_runner(binding_arg,kernel)
        initialization=[]
        for record in selection['records']:
            instance = formal.load_instance(record,adapter.runtime.core_smoke._native_path(bound['benchmark_root']))
            for method in selection['methods']:
                precision=sorted(formal.initial_precision(instance,method))
                assert precision == bound['expected_initialization'][record['instance_id']][method]
                initialization.append(dict(instance_id=record['instance_id'],method=method,precision=precision))
        adapter.runtime.write_json(work/'preflight.json',dict(status='PASSED',planner_calls=0,manifest=manifest,initialization=initialization))
        metadata['preflight_rc']=0
        command=[sys.executable,'-B',str(repo/'experiments/cmr_ros2_real/verify_small.py'),'--binding',binding_arg,'--kernel-root',kernel,'--output',str(work/'qualification')]
        with (work/'stdout.txt').open('w') as out,(work/'stderr.txt').open('w') as err:
            result=subprocess.run(command,stdout=out,stderr=err)
        metadata['qualification_rc']=result.returncode
        (work/'qualification.rc').write_text(str(result.returncode)+'\n')
        code=result.returncode
    except Exception as error:
        details=traceback.format_exc()
        (work/'preflight_error.txt').write_text(details)
        adapter.runtime.write_json(work/'preflight.json',dict(status='FAILED',planner_calls=0,error=repr(error)))
        metadata['preflight_rc']=1
        traceback.print_exc()
    finally:
        metadata.update(after={path:info(path) for path in paths},completion_ns=time.time_ns())
        metadata['sources_unchanged']=metadata['before']==metadata['after']
        adapter.runtime.write_json(work/'runner.json',metadata)
        (work/'preflight.rc').write_text(str(metadata['preflight_rc'])+'\n')
        assert metadata['sources_unchanged']
    print(json.dumps(dict(output=str(work),preflight_rc=metadata['preflight_rc'],qualification_rc=metadata['qualification_rc'],sources_unchanged=metadata['sources_unchanged'])))
    raise SystemExit(code)

if __name__ == '__main__':
    main()