import hashlib
import json
from pathlib import Path
root = Path(r'D:\Robotics\Robotics4LLM\ltl_automaton_core-ros2\experiments\cmr_ros2_real')
path = root / 'selection.json'
selection = json.loads(path.read_text())
sources = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('*.py'))}
assert set(sources) == {'bound_runner.py','runner.py','verify_small.py','dds_real.py','verifier_checks.py'}
closure = hashlib.sha256(json.dumps(sources,sort_keys=True,separators=(',',':')).encode()).hexdigest()
selection['adapter_source_sha256'] = sources
selection['execution_identity'] = selection['source_head'] + '+cmr-real-' + closure[:16]
path.write_text(json.dumps(selection,indent=2)+'\n',encoding='utf-8')
print(selection['execution_identity'])