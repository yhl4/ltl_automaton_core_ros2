import json
from pathlib import Path
root=Path('/tmp/ltl_cmr_ros2_real_6778dcb_20261012_fix1')
q=json.loads((root/'qualification/qualification.json').read_text())
rows=[]
for pair in q['pairs']:
    for backend in ('reference','ros2'):
        value=pair[backend]
        rows.append(dict(role=backend,instance_id=pair['instance_id'],method=pair['method'],pid=value['worker_pid']))
dds=q['dds']
for role,pid in dds['pids'].items():
    rows.append(dict(role='dds_'+role,pid=pid))
rows.append(dict(role='dds_worker',pid=dds['driver']['result']['worker_pid']))
for row in rows:
    path=Path('/proc',str(row['pid']),'cmdline')
    command=path.read_bytes() if path.exists() else b''
    row['pid_exists_at_check']=bool(command)
    row['matching_task_process_alive']=b'cmr_ros2_real/' in command and str(root).encode() in command
assert all(not row['matching_task_process_alive'] for row in rows)
(root/'process_cleanup.json').write_text(json.dumps(dict(status='PASSED',processes=rows),indent=2)+'\n')
print(json.dumps(dict(status='PASSED',process_count=len(rows))))