import copy
import hashlib
import json
from fractions import Fraction
from pathlib import Path
import sys

root=Path(sys.argv[1])
def read(relative):
    return json.loads((root/relative).read_text(encoding='utf-8'))
def native(path):
    if path.startswith('/mnt/d/'):
        return Path('D:/'+path[7:])
    if path.startswith('/mnt/c/'):
        return Path('C:/'+path[7:])
    raise ValueError(path)
def info(path):
    raw=Path(path).read_bytes()
    return dict(size=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def row_hash(row):
    value=dict(row)
    value.pop('result_hash',None)
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
runner=read('runner.json')
assert runner['sources_unchanged'] and runner['before']==runner['after']
assert runner['preflight_rc']==runner['qualification_rc']==0
assert (root/'wsl.rc').read_text().strip()=='0'
for path,expected in runner['after'].items():
    assert info(native(path))==expected,path
q=read('qualification/qualification.json')
assert q['status']=='PASSED' and q['scope']=='CORE_SUBSET_QUALIFICATION' and not q['formal_campaign']
selection=read('qualification/selection.json')
assert len(q['pairs'])==9
assert [(p['instance_id'],p['method']) for p in q['pairs']]==[(r['instance_id'],m) for r in selection['records'] for m in selection['methods']]

def manifest(m):
    assert len(m['source_checks'])==40 and len(m['imports'])==8 and len(m['runner_imports'])==6
    assert m['bound_runner']['other_ast_unchanged'] and len(m['bound_runner']['rebases'])==2
    for entry in list(m['imports'].values())+list(m['runner_imports'].values()):
        assert entry['__file__']==entry['expected_path']
        assert entry['sha256']==entry['expected_sha256']
        assert info(native(entry['__file__']))==dict(size=entry['size'],sha256=entry['sha256'])
    for row in m['source_checks']:
        assert row['match'] and info(native(row['path']))['sha256']==row['expected_sha256']==row['actual_sha256']

summary=[]
certificates=0
for pair in q['pairs']:
    assert pair['status']=='PASSED'
    left,right=pair['reference'],pair['ros2']
    assert left['row']['terminal_status']==right['row']['terminal_status']
    assert left['row']['initial_S0']==right['row']['initial_S0']
    for backend,value in [('reference',left),('ros2',right)]:
        row=value['row']
        assert value['worker_exitcode']==0 and not value['worker_alive_after_cleanup']
        assert row['result_hash']==row_hash(row)
        assert row['execution_commit']==selection['execution_identity']
        assert row['T_total']==(row['terminal_completion_ns']-row['method_start_ns'])/1e9
        assert row['terminal_completion_ns']<row['method_start_ns']+180_000_000_000
        assert row['qualification_scope']=='CORE_SUBSET_QUALIFICATION' and not row['formal_campaign']
        manifest(value['manifest'])
        attempt=root/'qualification'/f'{pair["instance_id"]}_{pair["method"]}_{backend}'
        schema_binding=json.loads((attempt/'schema_binding.json').read_text())
        receipt=json.loads(native('/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json').read_text())
        for kind in ('result','round'):
            ref=receipt['scientific_source_refs'][kind+'_schema']
            original=json.loads(Path(ref['path']).read_text())
            active=copy.deepcopy(schema_binding['schemas'][kind])
            assert schema_binding['source_hashes'][kind]==ref['sha256']
            if backend=='ros2':
                assert active['$id']==original['$id']+':ros2-backend-binding-v1'
                assert active['properties']['backend_sha256']['const']==row['backend_sha256']
                active['$id']=original['$id']
                active['properties']['backend_sha256']['const']=original['properties']['backend_sha256']['const']
            assert active==original
        if backend=='ros2':
            assert value['backend_configuration']['loop_code_preserved'] and value['backend_configuration']['local_code_preserved']
            assert row['backend_id']=='ROS2-DISCRETE-PLAN-CMR-LASSO-V1'
            for work in value['search_work']:
                assert work['completed'] and work['queue_pushes']==work['queue_pops']
                assert work['prefix_settled']==sum(h['returned_len'] for h in work['helpers'] if h['helper']=='_prefix_distances')
                assert work['suffix_settled']==sum(h['returned_len'] for h in work['helpers'] if h['helper']=='_component_distances')
        rounds=row['rounds'] or []
        assert all(set(a['S_k'])<set(b['S_k']) for a,b in zip(rounds,rounds[1:]))
        if row['terminal_status']=='OPTIMALITY_CERTIFIED':
            assert row['certificate_verifier_status']=='PASS' and row['certificate_valid_for_terminal']
            path=root/'qualification'/f'{pair["instance_id"]}_{pair["method"]}_{backend}'/'certificates'/row['certificate_path']
            assert info(path)['sha256']==row['certificate_hash']
            c=json.loads(path.read_text())
            assert c['instance_id']==pair['instance_id'] and c['method']==pair['method']
            assert c['execution_commit']==selection['execution_identity']
            lasso=c['full_model_lasso']
            assert lasso['prefix'][-1]==lasso['suffix'][0]==lasso['suffix'][-1]
            assert lasso['suffix_edges']
            totals=[]
            for part in ('prefix','suffix'):
                states,edges=lasso[part],lasso[part+'_edges']
                assert len(states)==len(edges)+1
                for s,e,t in zip(states,edges,states[1:]):
                    assert e['source']==s and e['target']==t
                totals.append(sum((Fraction(e['cost']) for e in edges),Fraction(0)))
            assert totals[0]==Fraction(c['prefix_cost']) and totals[1]==Fraction(c['suffix_cost'])
            assert totals[0]+10*totals[1]==Fraction(c['objective'])==Fraction(row['objective'])
            certificates+=1
        else:
            assert row['terminal_status']=='INFEASIBLE_CERTIFIED'
            assert row['objective'] is None and value['transport'] is None
            assert row['infeasibility_certificate_type']=='REDUCED_PRODUCT_EXACT_EMPTY'
    if left['row']['objective'] is not None:
        assert Fraction(left['row']['objective'])==Fraction(right['row']['objective'])
    summary.append(dict(instance_id=pair['instance_id'],method=pair['method'],status=right['row']['terminal_status'],objective=right['row']['objective'],reference_seconds=left['row']['T_total'],ros2_seconds=right['row']['T_total'],reference_rounds=len(left['row']['rounds']),ros2_rounds=len(right['row']['rounds'])))
assert q['verifier_negatives']['status']=='PASSED' and q['verifier_negatives']['rejected']==2
assert all(c['status']=='REJECTED' for c in q['verifier_negatives']['cases'])
dds=q['dds']
assert dds['status']=='PASSED' and dds['domain_id']==219 and dds['rc']==dict(server=0,driver=0)
result=dds['driver']['result']
assert result['instance_id']=='C1-T1' and result['method']=='AP-D'
assert result['terminal_status']=='OPTIMALITY_CERTIFIED' and result['certificate_verifier_status']=='PASS'
dds_value=read('qualification/dds/cmr_attempt/result.json')
assert dds_value['row']['result_hash']==row_hash(dds_value['row'])
assert all(result[key]==value for key,value in dds_value['row'].items())
manifest(dds_value['manifest'])
dds_cert=root/'qualification/dds/cmr_attempt/certificates'/result['certificate_path']
assert info(dds_cert)['sha256']==result['certificate_hash']
dds_certificate=json.loads(dds_cert.read_text())
assert dds_certificate['execution_commit']==selection['execution_identity']
assert Fraction(dds_certificate['objective'])==Fraction(result['objective'])
peer=next(p['ros2']['row'] for p in q['pairs'] if p['instance_id']=='C1-T1' and p['method']=='AP-D')
assert Fraction(result['objective'])==Fraction(peer['objective'])
assert dds['executed_steps']==dds['prefix_steps']+dds['suffix_steps']
for key in ('completion_count','observer_feedback_count','abstraction_feedback_count','ts_state_receive_count'):
    assert dds['driver'][key]==dds['executed_steps']
assert len({*dds['pids'].values(),result['worker_pid']})==3
for name,path in dds['driver']['module_resolved_paths'].items():
    assert info(native(path))['sha256']==dds['driver']['module_sha256'][name]
value=dict(schema='cmr-ros2-real-native-readback-v1',status='PASSED',planner_imported=False,scope=q['scope'],frozen_inputs=len(runner['after']),pairs=summary,independent_certificates=certificates,independent_dds_certificates=1,negative_rejections=2,dds=dict(status='PASSED',instance_id='C1-T1',method='AP-D',prefix_steps=dds['prefix_steps'],suffix_steps=dds['suffix_steps'],objective=result['objective']))
(root/'native_readback.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
print(json.dumps(value))