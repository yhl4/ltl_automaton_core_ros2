#!/usr/bin/env bash
set -eo pipefail
repo=/tmp/cmr_v7_current_campaign_source_388326a_20261013_r1
logs=/mnt/c/Users/Yuhling/.codex/worktrees/v7-audit-dds-regression/campaign_current_20261013
git clone --no-hardlinks --single-branch --branch codex/v7-audit-dds-regression /mnt/d/Robotics/Robotics4LLM/ltl_automaton_core-ros2/.git "$repo" > "$logs/clone.txt" 2>&1
test "$(git -C "$repo" rev-parse HEAD)" = 388326a00c21ec59320c52f05391511f493a7d77
git -C "$repo" status --porcelain > "$logs/source_status.txt"
test ! -s "$logs/source_status.txt"
source /opt/ros/humble/setup.bash
source /tmp/ltl_ros2_combo_bd75495/install/setup.bash
export PYTHONDONTWRITEBYTECODE=1 ROS_LOCALHOST_ONLY=1
export PYTHONPATH="$repo/ltl_automaton_execution:$repo/ltl_automaton_planner:$repo/ltl_automaton_planner_core:$repo:$PYTHONPATH"
cd "$repo"
python3 -B "$logs/prepare.py" > "$logs/prepare.txt" 2>&1
cat "$logs/prepare.txt"
