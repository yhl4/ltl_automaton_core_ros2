"""Standard-library readback only: no worker, planner, or verifier calls."""
import hashlib
import json
from fractions import Fraction
from pathlib import Path
import zipfile

root = Path('/tmp/cmr_v7_current_campaign_20261013_r3')
repo = Path('/tmp/cmr_v7_current_campaign_source_0c09617_20261013_r3')
sha_bytes = lambda data: hashlib.sha256(data).hexdigest()
sha = lambda path: sha_bytes(Path(path).read_bytes())
read = lambda path: json.loads(Path(path).read_bytes())
canonical = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
raw = lambda value: (canonical(value) + '\n').encode()
campaign = root / 'campaign'
report = read(campaign / 'campaign_report.json')
plan = read(root / 'plan/plan.json')
binding = read(campaign / 'campaign_binding.json')
assert report['status'] == 'PASSED'
assert report['source_head'] == '0c096178bdd44f4f908cb4cc14e34c32f96abb00'
assert report['new_method_workers'] == 1 and report['resume_method_workers'] == 0
assert report['backend_binding']['backend'] == 'ros2-v7'
assert report['backend_binding']['backend_sha256'] == '3d9f94098e0a98db657bc46fcadfd89c65b7ca85b8c0aa4a175231ea63f2c8e2'
assert report['backend_binding']['version_binding_id'] == 'CMR_SEARCH_ENTRY_V1-2325092433cf5abc'
assert sha(campaign / 'campaign_binding.json') == report['campaign_binding_sha256']
assert sha(root / 'plan/plan.json') == report['source_plan_sha256']
content = dict(binding)
identifier = content.pop('binding_id')
assert identifier == 'CMR_QUALIFIED_CAMPAIGN_V1-' + sha_bytes(canonical(content).encode())[:16]
assert binding['cell_count'] == len(binding['cells']) == binding['method_attempts'] == 1
assert binding['qualification_only'] is True and binding['real_execution_authorized'] is False
assert binding['planner_budget_seconds'] == 180 and binding['outer_watchdog_seconds'] == 195
assert binding['formal_campaign'] is False
assert plan['expected_method_workers'] == 9
for path, expected in binding['gate_source_closure'].items():
    assert sha(path) == expected
for path, expected in plan['source_closure'].items():
    assert sha(repo / path) == expected
    assert sha(root / 'plan/frozen_adapter' / path) == expected
assert len(plan['source_closure']) == 56
before = read(root / 'plan/frozen_inputs_before.json')
after = {path: dict(size=Path(path).stat().st_size, sha256=sha(path)) for path in before}
assert before == after and len(after) == 60
(root / 'plan/frozen_inputs_after.json').write_bytes(raw(after))
attempts = list((campaign / 'attempts').glob('*/*/request.json'))
assert len(attempts) == 1
attempt = attempts[0].parent
assert read(attempt / 'request.json')['backend'] == 'ros2-v7'
value = read(attempt / 'result.json')
row = value['row']
assert value['worker_exitcode'] == 0 and value['worker_alive_after_cleanup'] is False
assert value['backend_binding'] == report['backend_binding']
assert row['execution_commit'] == plan['execution_identity']
assert row['result_hash'] == sha_bytes(canonical({k:v for k,v in row.items() if k != 'result_hash'}).encode())
assert row['terminal_status'] == 'OPTIMALITY_CERTIFIED' and Fraction(row['objective']) == 12
assert row['initial_S0'] == [3] and len(row['rounds']) == len(value['build_work']) == 6
for item in [row, *row['rounds']]:
    assert all(item[key] == val for key, val in report['backend_binding'].items())
assert row['rounds'][-1]['S_k'] == list(range(6))
final = campaign / 'completed' / binding['cells'][0]['cell_id']
assert read(final / 'validated_result.json') == row
assert (final / 'validated_result.json').read_bytes() == raw(row)
assert (final / 'rounds.jsonl').read_bytes() == b''.join(raw(item) for item in row['rounds'])
for name, expected in read(final / 'commit_manifest.json').items():
    assert sha(final / name) == expected
certificate = read(final / 'certificate.json')
assert sha(final / 'certificate.json') == row['certificate_hash']
assert (attempt / 'certificates' / row['certificate_path']).read_bytes() == (final / 'certificate.json').read_bytes()
assert certificate['execution_commit'] == row['execution_commit']
assert Fraction(certificate['prefix_cost']) + 10 * Fraction(certificate['suffix_cost']) == Fraction(certificate['objective']) == 12
lasso = certificate['full_model_lasso']
assert lasso['suffix_edges'] and lasso['suffix'][0] == lasso['suffix'][-1]
assert sum((Fraction(e['cost']) for e in lasso['prefix_edges']), Fraction()) == Fraction(certificate['prefix_cost'])
assert sum((Fraction(e['cost']) for e in lasso['suffix_edges']), Fraction()) == Fraction(certificate['suffix_cost'])
assert any(p['buchi_state'] in certificate['accepting_buchi_states'] for p in lasso['suffix'])
record, ledger = read(final / 'pilot_record.json'), read(final / 'ledger_entry.json')
assert ledger['previous_ledger_sha256'] is None
assert ledger['validated_result_hash'] == row['result_hash']
assert sha_bytes(raw(ledger)) == record['ledger_commit_sha256']
assert sha_bytes(raw({k:v for k,v in record.items() if k != 'ledger_commit_sha256'})) == ledger['record_payload_sha256']
assert (campaign / 'ledger.jsonl').read_bytes() == raw(ledger)
assert (campaign / 'core_results.jsonl').read_bytes() == raw(record)
assert record['campaign_binding_sha256'] == record['execution_binding_sha256'] == report['campaign_binding_sha256']
assert len(report['verifications']) == 2 and all(v['status'] == 'PASS' for v in report['verifications'])
for verification in report['verifications']:
    assert sha(verification['path']) == verification['sha256'] == row['certificate_hash']
original_archive = Path('/mnt/c/Users/Yuhling/.codex/worktrees/v7-audit-dds-regression/ltl_automaton_core-ros2/experiments/cmr_ros2_search_entry/evidence/20261013_audit_real/raw_attempts.zip')
assert sha(original_archive) == '3626a630cccaae0d3f4e765455ddc43cb220a47c149ed84ab89cfce4bcb505d6'
with zipfile.ZipFile(original_archive) as archive:
    original = json.loads(archive.read('C3-T4_AP-D/reference/result.json'))['row']
    old_plan = json.loads(archive.read('plan.json'))
    comparison = json.loads(archive.read('comparison.json'))
    prior = next(c for c in comparison['cells'] if (c['instance_id'], c['method']) == ('C3-T4', 'AP-D'))
    old_certificate = json.loads(archive.read('C3-T4_AP-D/reference/certificates/C3-T4__AP-D__121.json'))
    assert sha_bytes(archive.read('C3-T4_AP-D/reference/certificates/C3-T4__AP-D__121.json')) == original['certificate_hash']
assert old_plan['manifest_sha256'] == plan['manifest_sha256']
assert old_plan['original_execution_binding_sha256'] == plan['original_execution_binding_sha256']
for key in ('instance_sha256', 'formula_sha256', 'formula_ast_sha256', 'semantic_contract_sha256', 'gamma', 'objective'):
    assert old_certificate[key] == certificate[key]
assert original['terminal_status'] == row['terminal_status'] and original['initial_S0'] == row['initial_S0']
assert len(original['rounds']) == len(row['rounds'])
assert prior['certificate_replays']['reference']['status'] == 'PASS'
for index in (1, 2):
    previous = Path('/tmp/cmr_v7_current_campaign_20261013_r' + str(index))
    assert not list(previous.rglob('request.json'))
    assert not (previous / 'campaign/dispatch.json').exists()
fatal = read('/tmp/cmr_v7_current_campaign_20261013_r2/campaign/fatal.json')
assert "KeyError: 'binding_id'" in fatal['traceback']
result = dict(status='PASSED', readback_kind='STDLIB_ONLY_NO_NEW_WORKERS_OR_VERIFIERS',
    new_method_workers=1, resume_method_workers=0, actual_publication_restore_verifier_calls=2,
    preparation_namespaces=3, predispatch_failure_workers=0,
    fixed_instance='C3-T4', method='AP-D', objective=row['objective'], initial_S0=row['initial_S0'], rounds=len(row['rounds']),
    method_T_total=row['T_total'], controller_work_separate_from_original_method_T_total=True,
    delivered_row_unchanged=True, frozen_inputs_checked=len(before), runtime_sources_checked=len(plan['source_closure']),
    gate_sources_checked=len(binding['gate_source_closure']), campaign_binding_id=identifier,
    campaign_binding_sha256=report['campaign_binding_sha256'], certificate_sha256=row['certificate_hash'],
    historical_reference_archive_sha256=sha(original_archive), historical_reference_verdict=original['terminal_status'],
    historical_reference_objective=original['objective'], historical_reference_certificate_replay='PASS_FROM_ORIGINAL_EVIDENCE',
    comparison_kind='COST_VERDICT_INPUT_IDENTITY_ONLY_NO_FRESH_REFERENCE_WORKER_OR_PAIRED_SPEED_CLAIM',
    provider_calls=0, dds_calls=0, formal_campaign=False, default_changed=False,
    frozen_formal_Campaign_constructor='UNRUN', full_510_cell_chain='UNVERIFIED')
(campaign / 'campaign_readback.json').write_bytes(raw(result))
print(json.dumps(result))
