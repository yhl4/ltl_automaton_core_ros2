from pathlib import Path
from types import SimpleNamespace
from experiments.cmr_ros2_search_entry import runner, fixtures, entry_fixtures

root = Path('/tmp/cmr_v7_current_campaign_20261013_r2')
receipt = '/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json'
kernel = '/mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel'
runner.prepare(SimpleNamespace(output=root / 'plan', binding=receipt, kernel_root=kernel,
                               continue_from=None, qualification_profile='search'))
plan = runner.load_plan(root / 'plan/plan.json')
runner.write(root / 'plan/search_fixtures.json', fixtures.run())
runner.write(root / 'plan/entry_fixtures.json', entry_fixtures.run_fixtures())
runner.write(root / 'plan/fixtures.json', dict(status='PASSED', execution_identity=plan['execution_identity'],
    version_binding_id=plan['version_binding_id'], version_binding_sha256=plan['version_binding_sha256']))
print('PREPARED: no method workers dispatched; current campaign authorizes exactly one cell')
