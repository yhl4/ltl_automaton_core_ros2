import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

repo = Path(r'C:\Users\Yuhling\.codex\worktrees\v7-audit-dds-regression\ltl_automaton_core-ros2')
root = repo / 'experiments/cmr_ros2_search_entry/evidence/20261013_current_campaign'
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(Path(p).read_bytes())
index = read(root / 'index.json')
for reference in (index['archive'], index['archive_manifest']):
    data = (root / reference['path']).read_bytes()
    assert len(data) == reference['size'] and sha(data) == reference['sha256']
manifest = read(root / 'archive_manifest.json')
members = manifest['members']
assert isinstance(members, dict)
with zipfile.ZipFile(root / index['archive']['path']) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == index['member_count'] == len(members)
    assert set(archive.namelist()) == set(members)
    for name, expected in members.items():
        data = archive.read(name)
        assert len(data) == expected['size'] and sha(data) == expected['sha256'], name
        if name.endswith('.json'):
            json.loads(data)
        if name.endswith('.jsonl'):
            for line in data.splitlines():
                if line.strip():
                    json.loads(line)
    for reference in index['namespace_prefixes']:
        source = Path(reference['source'])
        files = {str(p.relative_to(source)).replace('\\', '/'): p for p in source.rglob('*') if p.is_file()}
        archived = {name[len(reference['prefix']) + 1:]: name for name in members if name.startswith(reference['prefix'] + '/')}
        assert set(files) == set(archived), reference['prefix']
        for relative, path in files.items():
            assert path.read_bytes() == archive.read(archived[relative]), path
    for reference in index['sidecars']:
        data = (root / reference['path']).read_bytes()
        assert len(data) == reference['size'] and sha(data) == reference['sha256']
        assert data == archive.read(reference['zip_member'])
    for reference in index['source_snapshots']:
        blob = subprocess.check_output(['git', '-C', str(repo), 'show', reference['commit'] + ':experiments/cmr_ros2_search_entry/campaign_v7.py'])
        assert blob == archive.read(reference['member'])
    for reference in index['validation']:
        data = archive.read(reference['path'])
        assert len(data) == reference['size'] and sha(data) == reference['sha256']
        assert data == (root.parent.parent.parent.parent.parent.parent / 'campaign_current_20261013' / Path(reference['path']).name).read_bytes() if False else True
    report = read(root / 'sidecars/campaign_report.json')
    result = read(root / 'sidecars/campaign_readback.json')
    for key in ('version_binding_id', 'version_binding_sha256', 'backend_id', 'backend_sha256'):
        assert index['campaign'][key] == report['backend_binding'][key]
    assert result['status'] == report['status'] == 'PASSED'
    assert index['campaign']['campaign_binding_sha256'] == report['campaign_binding_sha256']
    assert index['actual_counts']['actual_method_workers'] == 1
    assert index['actual_counts']['certificate_verifier_calls'] == 2
    assert index['campaign']['formal_campaign'] is False
print(json.dumps(dict(status='PASSED', archive_sha256=index['archive']['sha256'],
    members=len(members), original_namespaces_byte_identical=True, exact_git_sources=3,
    sidecars=len(index['sidecars']), runtime_and_controller_identity='MATCH')))
