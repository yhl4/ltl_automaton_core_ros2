#!/usr/bin/env bash
set -eo pipefail
repo=/tmp/cmr_v7_current_campaign_source_388326a_20261013_r1
logs=/mnt/c/Users/Yuhling/.codex/worktrees/v7-audit-dds-regression/campaign_current_20261013
source /opt/ros/humble/setup.bash
source /tmp/ltl_ros2_combo_bd75495/install/setup.bash
export PYTHONDONTWRITEBYTECODE=1 ROS_LOCALHOST_ONLY=1
export PYTHONPATH="$repo/ltl_automaton_execution:$repo/ltl_automaton_planner:$repo/ltl_automaton_planner_core:$repo:$PYTHONPATH"
cd "$repo"
python3 -B -m experiments.cmr_ros2_search_entry.campaign_v7 \
 --backend ros2-v7 --plan /tmp/cmr_v7_current_campaign_20261013_r1/plan/plan.json \
 --binding /mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json \
 --kernel-root /mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel \
 --output /tmp/cmr_v7_current_campaign_20261013_r1/campaign > "$logs/campaign.txt" 2>&1
cat "$logs/campaign.txt"
