"""Continue only the unrun stages after the retained offline launcher failure."""
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path('/tmp/cmr_unified_v12_d796533_20261025_r3')
control=root/'control'
for phase in ('core','zero-core','lifecycle','boundary','feedback','dds','zero-dds'):
    if (control/(phase+'.rc')).read_text().strip()!='0':
        raise SystemExit('prerequisite not passed: '+phase)
if (control/'offline.rc').read_text().strip()!='1':
    raise SystemExit('not the retained offline launch failure')
env=Path(__file__).with_name('env_r3.sh')
for phase in sys.argv[1:]:
    with (control/(phase+'.launch.json')).open('x') as stream:
        json.dump(dict(phase=phase,start_ns=time.time_ns(),command=['bash',str(env),phase]),stream)
    with (control/(phase+'.log')).open('w') as log:
        result=subprocess.run(['bash',str(env),phase],stdout=log,stderr=subprocess.STDOUT)
    (control/(phase+'.rc')).write_text(str(result.returncode)+'\n')
    if result.returncode:
        raise SystemExit(result.returncode)
