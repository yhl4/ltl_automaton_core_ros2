"""Resume only outside the interrupted namespace, retaining original identities."""
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback

import stage
from experiments.cmr_ros2_unified_v12 import runner

OLD=Path('/tmp/cmr_unified_v12_44a542e_20261023')
NEW=Path(os.environ['CMR_OUT'])


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if sys.argv[1]!='core-continue':
        return stage.main()
    args=stage.args_for()
    NEW.mkdir(exist_ok=True)
    if args.output.exists():
        raise ValueError('fresh continuation namespace required')
    original=OLD/'main'
    old_plan=runner.load_plan(original/'plan.json')
    report=json.loads((original/'comparison.json').read_bytes())
    if report['status']!='RUNNING' or len(report['cells'])!=3:
        raise ValueError('interrupted attempt shape changed')
    if runner.frozen_inputs(old_plan)!=json.loads((original/'frozen_inputs_before.json').read_bytes()):
        raise ValueError('frozen input changed across interruption')
    if subprocess.check_output(['git','-C',str(runner.ROOT),'status','--porcelain'],text=True):
        raise ValueError('runtime source checkout is dirty')
    old_inventory={str(p.relative_to(OLD)):dict(size=p.stat().st_size,sha256=sha(p))
                   for p in OLD.rglob('*') if p.is_file()}
    observation=dict(status='INTERRUPTED_WITHOUT_EXIT_CODE',original_namespace=str(OLD),
        cause='not established; original supervisor/worker no longer present',
        original_report_status=report['status'],qualified_deliveries=6,
        recorded_additional_replays=6,incomplete_dispatch='B-D-BRANCH-S2/FULL/reference',
        original_inventory=old_inventory,original_directory_resumed=False)
    runner.write(NEW/'interruption_observation.json',observation)
    args.output.mkdir()
    for name in ('plan.json','backend_binding.json','fixtures.json','frozen_inputs_before.json'):
        shutil.copyfile(original/name,args.output/name)
    shutil.copytree(original/'frozen_adapter',args.output/'frozen_adapter')
    qualified=[]
    for item in report['cells']:
        if item['instance_id']!=runner.ANCHORS[0] or set(item['backends'])!=set(runner.NAMES):
            raise ValueError('unexpected continued controls')
        runner.v7.qualification.check_pair(item['backends']['reference'],item['backends']['ros2-v12'],item['method'])
        folder=item['instance_id']+'_'+item['method']
        for name in runner.NAMES:
            value=item['backends'][name]
            source=original/folder/name
            if (value['row']['terminal_status']!='OPTIMALITY_CERTIFIED'
                    or value['worker_exitcode']!=0 or value['worker_alive_after_cleanup'] is not False
                    or item['certificate_replays'][name]['status']!='PASS'
                    or json.loads((source/'result.json').read_bytes())!=value
                    or sha(source/'certificates'/value['row']['certificate_path'])!=value['row']['certificate_hash']
                    or json.loads((source/'additional_replay.json').read_bytes())!=item['certificate_replays'][name]):
                raise ValueError('continued worker/certificate bytes not qualified')
        shutil.copytree(original/folder,args.output/folder)
        item['status']='PASSED'
        qualified.append(item)
    plan=runner.load_plan(args.plan)
    result=dict(schema='cmr-unified-v12-comparison-v1',status='RUNNING',cells=qualified,
        formal_campaign=False,continuation=dict(original_namespace=str(OLD),
        original_plan_sha256=sha(original/'plan.json'),continued_workers=6,new_workers=20,
        original_identities_retained=True,interruption_observation_sha256=sha(NEW/'interruption_observation.json')))
    runner.write(args.output/'comparison.json',result)
    try:
        for cell in plan['cells'][3:]:
            folder=cell['instance_id']+'_'+cell['method']
            directory=args.output/folder;directory.mkdir()
            item=dict(instance_id=cell['instance_id'],method=cell['method'],backends={},certificate_replays={})
            result['cells'].append(item)
            for name in runner.NAMES:
                with (directory/('dispatch_'+name+'.json')).open('x') as stream:
                    json.dump(dict(backend=name,execution_identity=plan['execution_identity']),stream)
                value=runner.candidate_isolated(args,plan,cell,directory/name,backend_name=name)
                item['backends'][name]=value;runner.write(args.output/'comparison.json',result)
                replay=runner.replay(plan,args.binding,args.kernel_root,value,directory/name)
                item['certificate_replays'][name]=replay
                runner.write(directory/name/'additional_replay.json',replay)
                runner.write(args.output/'comparison.json',result)
                print(json.dumps(dict(instance=cell['instance_id'],method=cell['method'],backend=name,
                    status=value['row']['terminal_status'],objective=value['row']['objective'])),flush=True)
            runner.v7.qualification.check_pair(item['backends']['reference'],item['backends']['ros2-v12'],cell['method'])
            item['status']='PASSED'
        result['status']='PASSED'
    except Exception:
        result.update(status='FAILED',traceback=traceback.format_exc())
        raise
    finally:
        after=runner.frozen_inputs(plan);runner.write(args.output/'frozen_inputs_after.json',after)
        if after!=json.loads((args.output/'frozen_inputs_before.json').read_bytes()) or runner.source_closure()!=plan['source_closure']:
            result['status']='FAILED_SOURCE_OR_INPUT_CHANGED'
        runner.write(args.output/'comparison.json',result)
    if result['status']!='PASSED':
        raise ValueError('continuation failed')


if __name__=='__main__':
    main()
