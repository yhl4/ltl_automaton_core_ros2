"""Independent stdlib/Git readback of the packaged evidence; no planner imports."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import zipfile

LX_SYMLINK_REPARSE_TAG=0xA000001D


def is_link(path):
    info=path.lstat()
    return path.is_symlink() or getattr(info,'st_reparse_tag',0)==LX_SYMLINK_REPARSE_TAG


def link_target(path):
    info=path.lstat()
    if getattr(info,'st_reparse_tag',0)==LX_SYMLINK_REPARSE_TAG:
        raw=str(path.absolute())
        match=re.match(r'^\\\\(?:wsl\.localhost|wsl\$)\\([^\\]+)(.*)$',raw,re.IGNORECASE)
        need(match is not None,'cannot map WSL UNC link path: '+raw)
        distro,suffix=match.groups()
        linux_path='/'+suffix.replace('\\','/').lstrip('/')
        return subprocess.check_output(
            ['wsl.exe','-d',distro,'--exec','readlink','--',linux_path],
            stderr=subprocess.STDOUT,text=True).rstrip('\r\n')
    return os.readlink(path)


def runtime_entries(root):
    """Return an independent path/type inventory without traversing links."""
    entries={}
    for current,dirs,names in os.walk(root,followlinks=False):
        linked=[];kept=[]
        for name in dirs:
            path=Path(current)/name
            (linked if is_link(path) else kept).append(path)
        dirs[:]=[p.name for p in sorted(kept)]
        for path in linked:
            entries[path.relative_to(root).as_posix()]=('symlink',link_target(path))
        for name in names:
            path=Path(current)/name
            if is_link(path):
                entries[path.relative_to(root).as_posix()]=('symlink',link_target(path))
            elif path.is_file():
                entries[path.relative_to(root).as_posix()]=('file',None)
    return entries


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def need(value,message):
    if not value:
        raise AssertionError(message)


def main():
    parser=argparse.ArgumentParser()
    for key in ('repo','evidence','namespace','history','interrupted','validation'):
        parser.add_argument('--'+key,type=Path,required=True)
    args=parser.parse_args()
    evidence=args.evidence
    index=read(evidence/'index.json')
    manifest=read(evidence/'archive_manifest.json')
    assets=read(evidence/'artifact_manifest.json')
    for entry in assets['artifacts']:
        path=evidence/entry['path']
        need(path.stat().st_size==entry['size'] and sha(path.read_bytes())==entry['sha256'],
             'artifact manifest mismatch: '+entry['path'])
    members=manifest['members']
    archive=evidence/index['archive']
    need(len(members)==manifest['member_count'],'manifest member count mismatch')
    lookup={item['member']:item for item in members}
    need(len(lookup)==len(members),'duplicate manifest member')
    source_count=0
    plan=read(args.namespace/'main/plan.json')
    with zipfile.ZipFile(archive) as zipped:
        names=zipped.namelist()
        need(len(names)==len(set(names))==len(lookup) and set(names)==set(lookup),'ZIP inventory mismatch')
        for name in names:
            item=lookup[name];content=zipped.read(name)
            need(len(content)==item['size'] and sha(content)==item['sha256'],'ZIP member hash mismatch: '+name)
            if item.get('git_ref'):
                blob=subprocess.check_output(['git','-C',str(args.repo),'show',item['git_ref']+':'+item['git_path']])
                need(content==blob,'Git source snapshot mismatch: '+name)
                need(sha(blob)==plan['source_closure'][item['git_path']],
                     'executed source bytes differ from Git blob: '+name)
                source_count+=1
            elif item.get('type')=='symlink':
                source=Path(item['original_path'])
                need(is_link(source),'original symlink disappeared: '+name)
                target=link_target(source)
                need(target==item.get('symlink_target') and content==target.encode('utf-8'),
                     'original symlink target changed: '+name)
                info=zipped.getinfo(name)
                need(stat.S_IFMT(info.external_attr >> 16) == stat.S_IFLNK,
                     'ZIP member is not stored as a symlink: '+name)
            elif item.get('group')=='packaging_observation':
                observation=json.loads(content)
                need(observation.get('status')=='FAILED'
                     and observation.get('error')=='OSError Errno22 while opening a WSL UNIX symlink through Windows UNC'
                     and observation.get('wsl_link')=='/tmp/cmr_unified_v12_d796533_20261025_r3/feedback_artifacts/test_dds_repeated_targets_rejecurrent'
                     and observation.get('wsl_target')=='/tmp/cmr_unified_v12_d796533_20261025_r3/feedback_artifacts/test_dds_repeated_targets_reje1'
                     and observation.get('native_lstat',{}).get('st_reparse_tag')==LX_SYMLINK_REPARSE_TAG
                     and observation.get('native_lstat',{}).get('st_file_attributes')==1024
                     and observation.get('native_lstat',{}).get('is_symlink') is False
                     and observation.get('native_lstat',{}).get('is_file') is True
                     and observation.get('original_inputs_unchanged') is True
                     and observation.get('partial_staging_retained')=='validation/packaging_failed_unc_20261025',
                     'first packaging failure observation was not retained')
            else:
                source=Path(item['original_path'])
                need(source.is_file() and source.read_bytes()==content,'original bytes changed: '+name)
        for prefix,root in (('namespace',args.namespace),('history_namespace',args.history),('interrupted_namespace',args.interrupted)):
            entries=runtime_entries(root)
            expected={prefix+'/'+relative for relative in entries}
            observed={n for n in names if n.startswith(prefix+'/')}
            need(expected==observed,'runtime inventory not archived completely: '+prefix)
            for relative,(kind,target) in entries.items():
                item=lookup[prefix+'/'+relative]
                need(item.get('type','file')==kind,'runtime member type mismatch: '+prefix+'/'+relative)
                if kind=='symlink':
                    need(item.get('symlink_target')==target,'runtime symlink target mismatch: '+prefix+'/'+relative)
    need(source_count==7,'expected seven exact source Git blobs')
    proof=read(evidence/'root_scientific_readback.json')
    need(proof['status']=='PASSED' and proof['head']==manifest['source_commit'],'scientific proof source/status mismatch')
    need((evidence/'root_scientific_readback.json').read_bytes()==(args.namespace/'scientific_readback.json').read_bytes(),
         'scientific readback copy differs')
    before=read(args.validation/'before.json')
    for key,relative in (('v12','experiments/cmr_ros2_compact_cost/evidence/20261023/raw_attempts.zip'),
                         ('v11','experiments/cmr_ros2_exact_cost_reuse/evidence/20261023/raw_attempts.zip')):
        need(sha((args.repo/relative).read_bytes())==before['frozen_archives'][key],'frozen '+key+' archive changed')
    tag=subprocess.check_output(['git','-C',str(args.repo),'rev-parse','cmr-v7-baseline-00fc5a9^{commit}'],text=True).strip()
    need(tag==before['baseline_tag'],'V7 baseline tag changed')
    changed=subprocess.check_output(['git','-C',str(args.repo),'diff','--name-only',before['baseline_commit']],text=True).splitlines()
    need(all(name=='README.md' or name.startswith('experiments/cmr_ros2_unified_v12/') for name in changed),
         'unrelated tracked sources/evidence changed')
    result=dict(schema='cmr-unified-v12-root-archive-readback-v1',status='PASSED',
        source_commit=manifest['source_commit'],archive=archive.name,archive_sha256=sha(archive.read_bytes()),
        archive_bytes=archive.stat().st_size,archive_members=len(members),source_git_blobs=source_count,
        complete_runtime_inventories=True,original_member_bytes_unchanged=True,
        old_archives_unchanged=True,v7_baseline=tag,unrelated_tracked_changes=False,
        solver_calls=0,verifier_calls=0,dds_calls=0)
    result_path=evidence/'root_archive_readback.json'
    result_path.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    index.update(status='VERIFIED',archive_readback=dict(path=result_path.name,
        size=result_path.stat().st_size,sha256=sha(result_path.read_bytes())))
    for key in ('lifecycle','dds','directed','offline','provenance'):
        if key in proof:
            index['final_qualification'][key]=proof[key]
    index['limits']=dict(default_changed=False,formal_campaign=False,provider_calls=0,
        physical_execution=False,full_510_real_campaign='UNRUN',general_speedup='NOT_CLAIMED')
    (evidence/'index.json').write_text(json.dumps(index,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(result,sort_keys=True))


if __name__=='__main__':
    main()
