"""Remaining stages against the continued plan's original binding identity."""
import os
from pathlib import Path
import subprocess
import sys

import stage
from experiments.cmr_ros2_unified_v12 import runner

original_args_for=stage.args_for


def args_for(profile='main'):
    args=original_args_for(profile)
    if args.plan.exists():
        args.version_binding=Path(runner.load_plan(args.plan)['version_binding_path'])
    return args


stage.args_for=args_for
if sys.argv[1]=='provenance':
    import hashlib
    import rclpy
    from ltl_automaton_planner_core.ltl_tools import discrete_plan
    from ltl_automaton_execution import execution_node
    from ltl_automaton_planner import planning_graph_snapshot
    from ltl_automaton_msgs import msg
    code=Path(os.environ['CMR_CODE']).resolve()
    modules={module.__name__:dict(path=str(Path(module.__file__).resolve()),
        sha256=hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest())
        for module in (runner,discrete_plan,execution_node,planning_graph_snapshot,rclpy,msg)}
    for module in (runner,discrete_plan,execution_node,planning_graph_snapshot):
        if not Path(module.__file__).resolve().is_relative_to(code):
            raise AssertionError('runtime import outside selected source: '+module.__name__)
    runner.write(Path(os.environ['CMR_OUT'])/'provenance.json',dict(status='PASSED',modules=modules,
        ros_distro=os.environ.get('ROS_DISTRO'),worker_calls=0,solver_calls=0,dds_requests=0))
elif sys.argv[1]=='feedback':
    root=Path(os.environ['CMR_OUT'])
    subprocess.run([sys.executable,'-B','-m','pytest','-q',
        '--basetemp',str(root/'feedback_artifacts'),
        'experiments/cmr_ros2_integration/test_feedback.py',
        'experiments/cmr_ros2_integration/test_feedback_dds.py'],
        env=dict(os.environ,ROS_DOMAIN_ID='230',ROS_LOCALHOST_ONLY='1'),check=True)
elif sys.argv[1] in ('campaign','negatives'):
    args=args_for()
    subprocess.run([sys.executable,'-B',str(Path(__file__).with_name('directed_qualification.py')),
        '--phase',sys.argv[1],'--plan',str(args.plan),'--binding',str(args.binding),
        '--kernel-root',str(args.kernel_root),'--output',str(Path(os.environ['CMR_OUT'])/'directed')],check=True)
else:
    stage.main()
