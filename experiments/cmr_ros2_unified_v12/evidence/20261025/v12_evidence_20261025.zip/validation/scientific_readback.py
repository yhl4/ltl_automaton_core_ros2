#!/usr/bin/env python3
"""Fail-closed stdlib readback for the bounded unified V12 qualification."""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys

HEAD = "d79653300e7bed556a4d1583562e09f3c1dd6f88"
OLD_HEAD = "44a542e741b0dda258364ffe3ec27ab4d799852a"
ANCHORS = ("A-T1-M0-A-S-BRANCH", "B-D-BRANCH-S2", "C3-T4")
METHODS = ("FULL", "AP-D", "DEP-D")
BACKENDS = ("reference", "ros2-v12")
ZERO = "SYNTHETIC-UNIFIED-V12-ZERO-A"
PROOFS = ("infeasibility_certificate_type", "infeasibility_proof_basis",
          "infeasibility_precision", "lower_precision_infeasibility")
V7_NORMALIZE_KEYS = {"result_hash", "row_hash", "execution_commit",
                     "certificate_path", "certificate_hash", "certificate_objective",
                     "search_counter_basis", "qualification_scope", "population",
                     "version_binding_id", "version_binding_sha256"}


def need(ok, message):
    if not ok:
        raise AssertionError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def result_hash(row):
    body = dict(row)
    body.pop("result_hash", None)
    return sha_bytes(canonical(body))


def scalar(value):
    need(value is not None, "objective is null")
    return Fraction(str(value))


def v7_normalized(value):
    if isinstance(value, dict):
        return {k: v7_normalized(v) for k, v in value.items() if not
                (k.startswith("T_") or k.endswith("_ns") or k.endswith("_sha256")
                 or "backend" in k or k in V7_NORMALIZE_KEYS)}
    if isinstance(value, list):
        return [v7_normalized(v) for v in value]
    return value


def cell_map(report):
    cells = report.get("cells")
    if isinstance(cells, list):
        return {(c["instance_id"], c["method"]): c for c in cells}
    if isinstance(cells, dict):
        out = {}
        for key, c in cells.items():
            pair = (c.get("instance_id"), c.get("method"))
            if pair == (None, None) and "_" in key:
                pair = tuple(key.rsplit("_", 1))
            out[pair] = c
        return out
    raise AssertionError("comparison cells are not a list or map")


def git_head(source):
    dotgit = source / ".git"
    need(dotgit.exists(), "source checkout has no .git metadata for HEAD readback")
    if dotgit.is_dir():
        gitdir = dotgit
    else:
        line = dotgit.read_text(encoding="utf-8").strip()
        need(line.startswith("gitdir:"), "unrecognized .git worktree pointer")
        gitdir = (source / line.split(":", 1)[1].strip()).resolve()
    head = (gitdir / "HEAD").read_text(encoding="utf-8").strip()
    if not head.startswith("ref: "):
        return head
    ref = head[5:]
    loose = gitdir / ref
    if loose.is_file():
        return loose.read_text(encoding="ascii").strip()
    packed = gitdir / "packed-refs"
    if packed.is_file():
        for line in packed.read_text(encoding="ascii").splitlines():
            if line and not line.startswith(("#", "^")):
                value, name = line.split(" ", 1)
                if name == ref:
                    return value
    raise AssertionError("cannot resolve source Git HEAD ref")


def check_frozen(plan_dir, plan, report, expected_head=HEAD):
    before_path, after_path = plan_dir / "frozen_inputs_before.json", plan_dir / "frozen_inputs_after.json"
    before_bytes, after_bytes = before_path.read_bytes(), after_path.read_bytes()
    need(before_bytes == after_bytes, "frozen-input before/after bytes changed")
    before, after = json.loads(before_bytes), json.loads(after_bytes)
    need(before == after and bool(before), "frozen-input snapshots differ or are empty")
    for path_text, metadata in before.items():
        path = Path(path_text)
        need(path.is_file(), f"frozen input path is unavailable: {path_text}")
        need(path.stat().st_size == metadata["size"] and sha_file(path) == metadata["sha256"],
             f"current frozen input bytes differ: {path_text}")
    need(plan.get("source_head") == expected_head, "plan source_head is not the frozen HEAD")
    need(report.get("source_head", expected_head) == expected_head, "comparison source_head mismatch")
    return {"entries": len(before), "sha256": sha_bytes(before_bytes), "current_paths_checked": len(before)}


def check_source(source, plan, plan_dir, expected_head=HEAD):
    closure = plan.get("source_closure")
    need(isinstance(closure, dict) and len(closure) == 84, "source closure must contain 84 files")
    need(git_head(source) == expected_head, "source checkout Git HEAD mismatch")
    snapshots = plan_dir / "frozen_adapter"
    for rel, expected in closure.items():
        current = source / rel
        frozen = snapshots / rel
        need(current.is_file() and frozen.is_file(), f"source-closure file missing: {rel}")
        need(sha_file(current) == expected, f"source-closure hash mismatch: {rel}")
        need(sha_file(frozen) == expected, f"frozen source snapshot mismatch: {rel}")
    return {"head": expected_head, "closure_files": len(closure), "snapshots_checked": len(closure),
            "source_root": str(source)}


def case_folder(root, pair):
    return root / (pair[0] + "_" + pair[1])


def check_no_claims(value, expected, label):
    row = value["row"]
    need(row.get("terminal_status") == expected, f"{label}: wrong terminal status")
    need(row.get("objective") is None and value.get("transport") is None,
         f"{label}: failure carries objective or transport")
    need(row.get("certificate_valid_for_terminal") is False
         and row.get("certificate_verifier_status") == "NOT_AVAILABLE",
         f"{label}: failure claims a certificate")
    need(row.get("certificate_path", "NOT_AVAILABLE") == "NOT_AVAILABLE"
         and row.get("certificate_hash", "NOT_AVAILABLE") == "NOT_AVAILABLE",
         f"{label}: failure names a certificate file")
    need(all(row.get(k) is None for k in PROOFS), f"{label}: failure carries infeasibility proof")
    for rr in row.get("rounds") or []:
        need(rr.get("terminal_claim_valid") is False and all(rr.get(k) is None for k in PROOFS),
             f"{label}: round carries a terminal claim")
    need(value.get("worker_alive_after_cleanup") is False, f"{label}: worker cleanup failed")
    need(row.get("right_censored") is (expected == "TIMEOUT"), f"{label}: right-censoring mismatch")
    need(row.get("planner_budget_seconds") == 180 and row.get("outer_watchdog_seconds") == 195,
         f"{label}: timeout budgets changed")
    if expected == "TIMEOUT":
        need(row.get("timing_status") == "RIGHT_CENSORED" and row.get("T_total", 0) >= 180,
             f"{label}: timeout is not right-censored")


def check_result_artifacts(root, plan, binding, pair, backend, value, replay):
    folder = case_folder(root, pair) / backend
    result_path = folder / "result.json"
    stored = read(result_path)
    need(stored == value, f"{pair}/{backend}: delivered result differs from report")
    row = value["row"]
    plan_cell = next(c for c in plan["cells"] if (c["instance_id"], c["method"]) == pair)
    record = next(r for r in plan["records"] if r["instance_id"] == pair[0])
    expected_descriptor = dict(binding["backends"][backend], backend=backend,
                               version_binding_id=plan["version_binding_id"],
                               version_binding_sha256=plan["version_binding_sha256"])
    need(value.get("backend_binding") == expected_descriptor,
         f"{pair}/{backend}: result descriptor differs from frozen binding")
    need(row.get("execution_commit") == plan["execution_identity"]
         and row.get("initial_S0") == plan_cell["expected_initial_S0"]
         and row.get("qualification_scope") == plan["scope"]
         and row.get("formal_campaign") is False,
         f"{pair}/{backend}: row execution/initialization/scope provenance mismatch")
    need(row.get("instance_sha256") == record["instance_sha256"]
         and row.get("benchmark_payload_sha256") == record["instance_sha256"],
         f"{pair}/{backend}: row input/payload hash differs from bound record")
    need(row.get("planner_budget_seconds") == 180 and row.get("outer_watchdog_seconds") == 195,
         f"{pair}/{backend}: row timeout budgets changed")
    for target in [row, *(row.get("rounds") or [])]:
        need(target.get("backend") == backend, f"{pair}/{backend}: round backend identity mismatch")
        for key in ("backend_id", "backend_sha256", "version_binding_id", "version_binding_sha256"):
            need(target.get(key) == expected_descriptor[key], f"{pair}/{backend}: round descriptor mismatch: {key}")
        need(target.get("instance_id") == pair[0] and target.get("method") == pair[1]
             and target.get("instance_sha256") == record["instance_sha256"]
             and target.get("benchmark_payload_sha256") == record["instance_sha256"]
             and target.get("initial_S0") == plan_cell["expected_initial_S0"],
             f"{pair}/{backend}: round provenance/input hash mismatch")
    need(row.get("result_hash") == result_hash(row), f"{pair}/{backend}: result_hash mismatch")
    parent = read(folder / "parent_timing.json")
    checkpoint = parent.get("entry_timing", {}).get("delivery_checkpoint")
    need(isinstance(checkpoint, dict), f"{pair}/{backend}: parent release checkpoint missing")
    release_start, release_end = checkpoint.get("release_started_ns"), checkpoint.get("release_completed_ns")
    need(isinstance(release_start, int) and isinstance(release_end, int)
         and release_start <= release_end <= row.get("terminal_completion_ns", -1),
         f"{pair}/{backend}: parent release checkpoint ordering mismatch")
    method_elapsed_ns = row.get("qualified_runner_completion_ns", 0) - row.get("method_start_ns", 0)
    need(0 <= method_elapsed_ns < 180_000_000_000 and row.get("T_total", 180) < 180,
         f"{pair}/{backend}: normal method completion exceeded the 180-second budget")
    feasible = row.get("terminal_status") == "OPTIMALITY_CERTIFIED"
    if feasible:
        cert = folder / "certificates" / row["certificate_path"]
        cert_bytes = cert.read_bytes()
        need(sha_bytes(cert_bytes) == row["certificate_hash"], f"{pair}/{backend}: certificate SHA mismatch")
        replay_path = folder / "additional_replay.json"
        replay_file = read(replay_path)
        need(replay_file == replay and replay.get("status") == "PASS",
             f"{pair}/{backend}: independent replay missing or not PASS")
    else:
        need(row.get("terminal_status") == "INFEASIBLE_CERTIFIED", f"{pair}/{backend}: unexpected terminal")
        need(row.get("infeasibility_certificate_type") == "REDUCED_PRODUCT_EXACT_EMPTY",
             f"{pair}/{backend}: exact-empty proof metadata missing")
        need(row.get("certificate_path") in (None, "NOT_AVAILABLE")
             and row.get("certificate_hash") in (None, "NOT_AVAILABLE")
             and value.get("transport") is None,
             f"{pair}/{backend}: exact-empty result carries feasible-certificate material")
        need(replay.get("status") == "NOT_APPLICABLE"
             and replay.get("basis") == "original exact-empty proof metadata; paired reference required",
             f"{pair}/{backend}: fabricated feasible replay for empty result")
        need(read(folder / "additional_replay.json") == replay,
             f"{pair}/{backend}: original exact-empty replay record differs")
    return {"result_hash": row["result_hash"], "certificate_sha256": row.get("certificate_hash"),
            "replay_status": replay.get("status")}


def validate_comparison(root, profile, expected_count, expected_head=HEAD):
    plan_dir = root / profile
    plan = read(plan_dir / "plan.json")
    report = read(plan_dir / "comparison.json")
    need(report.get("status") == "PASSED" and report.get("formal_campaign") is False,
         f"{profile}: comparison not PASSED/bounded")
    need(len(plan.get("cells", [])) == expected_count and plan.get("expected_method_workers") == 2 * expected_count,
         f"{profile}: plan cell/worker count mismatch")
    cells = cell_map(report)
    binding = read(plan_dir / "backend_binding.json")
    need(len(cells) == expected_count, f"{profile}: report cell count mismatch")
    if profile == "main":
        expected = {(name, method) for name in ANCHORS for method in METHODS}
        expected |= {("D3-1", "AP-D")}
        expected |= {("D1-1", method) for method in METHODS}
        need(set(cells) == expected, "main comparison cell selection changed")
    else:
        need(set(cells) == {(ZERO, method) for method in METHODS}, "zero control selection changed")
    results = {}
    for pair, cell in cells.items():
        need(cell.get("status") == "PASSED", f"{profile}/{pair}: cell not PASSED")
        need(set(cell.get("backends", {})) == set(BACKENDS), f"{profile}/{pair}: backend pair incomplete")
        need(set(cell.get("certificate_replays", {})) == set(BACKENDS), f"{profile}/{pair}: replay pair incomplete")
        statuses = []
        objectives = []
        for backend in BACKENDS:
            value = cell["backends"][backend]
            row = value["row"]
            need(value.get("worker_exitcode") == 0 and value.get("worker_alive_after_cleanup") is False,
                 f"{profile}/{pair}/{backend}: worker exit/cleanup mismatch")
            need(row.get("instance_id") == pair[0] and row.get("method") == pair[1],
                 f"{profile}/{pair}/{backend}: result identity mismatch")
            statuses.append(row.get("terminal_status"))
            if pair[0] == "D1-1":
                need(row.get("terminal_status") == "INFEASIBLE_CERTIFIED" and row.get("objective") is None,
                     f"{pair}/{backend}: D1-1 must retain exact-empty infeasibility")
                need(row.get("infeasibility_certificate_type") == "REDUCED_PRODUCT_EXACT_EMPTY"
                     and row.get("infeasibility_proof_basis") is not None,
                     f"{pair}/{backend}: original infeasibility proof metadata missing")
                objectives.append(None)
            else:
                need(row.get("terminal_status") == "OPTIMALITY_CERTIFIED", f"{pair}/{backend}: expected optimal certificate")
                objectives.append(scalar(row.get("objective")))
                if backend == "ros2-v12":
                    validate_work(value, pair, pair[1])
            value_summary = check_result_artifacts(plan_dir, plan, binding, pair, backend, value,
                                                   cell["certificate_replays"][backend])
            if profile == "synthetic-zero":
                need(scalar(row.get("objective")) == 0, f"zero/{pair}/{backend}: objective is not exactly zero")
                lasso = value.get("transport") or {}
                concrete = lasso.get("concrete_lasso") or {}
                suffix, edges = concrete.get("suffix") or [], concrete.get("suffix_edges") or []
                need(bool(concrete.get("prefix")) and len(suffix) >= 2 and bool(edges)
                     and suffix[0] == suffix[-1]
                     and edges[0].get("source") == suffix[0]
                     and edges[-1].get("target") == suffix[0],
                     f"zero/{pair}/{backend}: nonempty accepting suffix/closing edge missing")
                need(plan.get("records", [{}])[0].get("cohort") == "CONTROL",
                     "zero profile manifest record is not CONTROL")
                input_path = Path(plan["synthetic_benchmark"]) / plan["records"][0]["path"]
                manifest = read(Path(plan["synthetic_benchmark"]) / "manifests" / "manifest.json")
                need(len(manifest) == 1 and manifest[0] == plan["records"][0]
                     and input_path.is_file()
                     and sha_file(input_path) == plan["records"][0]["instance_sha256"],
                     "zero CONTROL manifest/input bytes do not match the bound record")
            results[(pair, backend)] = {"value": value, "summary": value_summary}
        need(statuses[0] == statuses[1], f"{profile}/{pair}: reference/V12 verdict differs")
        if pair[0] == "D1-1":
            left, right = (cell["backends"][b]["row"] for b in BACKENDS)
            need(left.get("objective") is None and right.get("objective") is None
                 and cell["backends"][BACKENDS[0]].get("transport") is None
                 and cell["backends"][BACKENDS[1]].get("transport") is None,
                 f"{pair}: exact-empty result carries a scientific objective/transport")
            for field in PROOFS:
                need(left.get(field) == right.get(field),
                     f"{pair}: reference/V12 original proof metadata differs for {field}")
        else:
            need(objectives[0] == objectives[1], f"{profile}/{pair}: exact Fraction objective differs")
    frozen = check_frozen(plan_dir, plan, report, expected_head)
    return plan, report, cells, results, frozen


def directory_manifest(path):
    return {str(p.relative_to(path)): {"size": p.stat().st_size, "sha256": sha_file(p)}
            for p in sorted(path.rglob("*")) if p.is_file()}


def validate_work(value, pair, method):
    build = value.get("build_work")
    rounds = value["row"].get("rounds")
    need(isinstance(build, list) and build and isinstance(rounds, list) and rounds,
         f"{pair}: work/round records missing")
    rebuilds = sum(int(item.get("full_ts_rebuild_calls", 0)) for item in build)
    hits = sum(int(item.get("full_ts_cache_hits", 0)) for item in build)
    if method == "AP-D":
        need(rebuilds == 1 and hits == len(build) - 1,
             f"{pair}: AP-D must use one full TS build and reuse hits")
    else:
        need(len(build) == len(rounds) and rebuilds == len(rounds)
             and hits == 0 and all(int(item.get("full_ts_rebuild_calls", 0)) == 1 for item in build),
             f"{pair}: {method} must rebuild the full TS per round")


def compare_prior_transport(new_root, prior_root, new_cells):
    prior_report = read(prior_root / "comparison.json")
    need(prior_report.get("status") == "PASSED", "preserved compact-cost V12 comparison is not PASSED")
    prior = cell_map(prior_report)
    checked = []
    for pair in (("C3-T4", "AP-D"), ("D3-1", "AP-D")):
        need(pair in prior and pair in new_cells, f"prior/current V12 transport cell missing: {pair}")
        left = prior[pair]["backends"]["ros2-v12"]
        right = new_cells[pair]["backends"]["ros2-v12"]
        for label, val in (("prior", left), ("current", right)):
            validate_work(val, pair, "AP-D")
        need(left.get("transport") == right.get("transport"),
             f"{pair}: concrete transport differs from preserved V12")
        need(left["row"].get("terminal_status") == right["row"].get("terminal_status")
             and scalar(left["row"].get("objective")) == scalar(right["row"].get("objective")),
             f"{pair}: status or exact objective differs from preserved V12")
        for field in ("initial_S0", "final_precision", "refinement_rounds", "cumulative_work",
                      "final_unique_graph_size", "candidate_fingerprint"):
            need(left["row"].get(field) == right["row"].get(field),
                 f"{pair}: {field} differs from preserved V12")
        need(v7_normalized(left["row"]["rounds"]) == v7_normalized(right["row"]["rounds"]),
             f"{pair}: V7-normalized scientific rounds differ from preserved V12")
        need(v7_normalized(left.get("search_work"))
             == v7_normalized(right.get("search_work")),
             f"{pair}: V7-normalized search work differs from preserved V12")
        need(v7_normalized(left.get("build_work")) == v7_normalized(right.get("build_work")),
             f"{pair}: normalized AP-D build work differs from preserved V12")
        checked.append({"cell": list(pair), "result_hashes": {
            "prior": left["row"].get("result_hash"), "current": right["row"].get("result_hash")},
            "normalized_rounds_work": "MATCH"})
    return checked


def validate_lifecycle(root):
    report = read(root / "lifecycle" / "lifecycle.json")
    cases = report.get("cases", [])
    need(report.get("status") == "PASSED" and len(cases) == 10, "lifecycle must PASS all 10 cases")
    for item in cases:
        need(item.get("status") == "PASSED", "lifecycle case failure")
        mode = item["mode"]
        value = item["result"]
        expected = "TIMEOUT" if mode.startswith("late_") else "INFRASTRUCTURE_FAILURE"
        check_no_claims(value, expected, "lifecycle/" + mode)
    boundary = read(root / "boundary.json")
    need(boundary.get("status") == "PASSED" and boundary.get("count") == 11
         and boundary.get("new_workers") == 0, "11 deterministic final-boundary checks missing")
    need(all(c.get("status") == "PASSED" for c in boundary.get("checks", [])),
         "a final-boundary check did not pass")
    return {"cases": len(cases), "boundary_checks": boundary["count"]}


def validate_dds(path, zero=False):
    report = read(path / "dds_report.json")
    cases = report.get("cases", [])
    need(report.get("status") == "PASSED" and len(cases) == (1 if zero else 7),
         f"DDS report count/status mismatch: {path}")
    expected = {(ZERO, "FULL", "normal", "OPTIMALITY_CERTIFIED")} if zero else {
        ("C3-T4", m, "normal", "OPTIMALITY_CERTIFIED") for m in METHODS}
    if not zero:
        expected |= {("D1-1", "FULL", "normal", "INFEASIBLE_CERTIFIED"),
                     (ANCHORS[0], "FULL", "late_delivery", "TIMEOUT"),
                     (ANCHORS[0], "FULL", "crash", "INFRASTRUCTURE_FAILURE"),
                     (ANCHORS[0], "FULL", "server_error", "ERROR")}
    seen = set()
    for case in cases:
        need(case.get("status") == "PASSED", "DDS case did not pass")
        d = case["driver"].get("result", {})
        request = case["request"]
        mode = case.get("harness_mode")
        key = (case["request"]["instance_id"], case["request"]["method"],
               mode, d.get("terminal_status"))
        seen.add(key)
        need(case.get("server_rc") == 0 and case.get("driver_rc") == 0,
             f"DDS {key}: server/driver child failed")
        need(request.get("backend") == "ros2-v12" and d.get("request_id") == request.get("request_id"),
             f"DDS {key}: request/result identity mismatch")
        if key[3] == "OPTIMALITY_CERTIFIED":
            driver = case["driver"]
            commands = driver.get("commands", [])
            actions = driver.get("expected_actions") or []
            driver_events = driver.get("events", [])
            server_events = case.get("server", {}).get("events", [])
            event_names = [e.get("event") for e in server_events]
            required = ("request_received", "cmr_solver_started", "cmr_solver_completed", "result_published")
            need(bool(actions) and commands == actions and driver.get("execution_counts_match") is True,
                 f"DDS {key}: successful transport actions/counts mismatch")
            need(driver.get("completion_count") == len(actions)
                 and driver.get("observer_feedback_count") == len(actions)
                 and driver.get("abstraction_feedback_count") == len(actions),
                 f"DDS {key}: successful transport completion/feedback counts mismatch")
            for event_name in ("dispatch", "observer_feedback", "abstraction_feedback", "backend_completion"):
                need(sum(e.get("event") == event_name for e in driver_events) == len(actions),
                     f"DDS {key}: {event_name} count mismatch")
            dispatches = [e for e in driver_events if e.get("event") == "dispatch"]
            observers = [e for e in driver_events if e.get("event") == "observer_feedback"]
            abstractions = [e for e in driver_events if e.get("event") == "abstraction_feedback"]
            completions = [e for e in driver_events if e.get("event") == "backend_completion"]
            need([e.get("action") for e in dispatches] == actions
                 and [e.get("action") for e in completions] == actions
                 and all(e.get("success") is True for e in completions),
                 f"DDS {key}: dispatch/completion action order differs")
            need([e.get("execution_step_seq") for e in dispatches] == list(range(len(actions)))
                 and [e.get("execution_step_seq") for e in completions] == list(range(len(actions))),
                 f"DDS {key}: dispatch/completion step order differs")
            dpos = [driver_events.index(e) for e in dispatches]
            opos = [driver_events.index(e) for e in observers]
            apos = [driver_events.index(e) for e in abstractions]
            need(all(d < o < a for d, o, a in zip(dpos, opos, apos)),
                 f"DDS {key}: dispatch/observer/abstraction order differs")
            need(all(event_names.count(name) == 1 for name in required)
                 and event_names.index(required[0]) < event_names.index(required[1])
                 < event_names.index(required[2]) < event_names.index(required[3]),
                 f"DDS {key}: server lifecycle event order/count mismatch")
            required_times = [next(e["time_ns"] for e in server_events if e.get("event") == name)
                              for name in required]
            need(required_times == sorted(required_times), f"DDS {key}: server event timestamps out of order")
            need(sum(e.get("event") == "snapshot_served" for e in server_events) >= 1
                 and sum(e.get("event") == "request_published" for e in driver_events) == 1
                 and sum(e.get("event") == "result_received" for e in driver_events) == 1,
                 f"DDS {key}: snapshot/request/result events missing")
            need((case.get("certificate_replay") or {}).get("status") == "PASS",
                 f"DDS {key}: independent certificate replay missing")
        if key[3] == "INFEASIBLE_CERTIFIED":
            need(d.get("infeasibility_certificate_type") == "REDUCED_PRODUCT_EXACT_EMPTY",
                 "DDS exact-empty result lost original proof metadata")
    need(seen == expected, f"DDS target/status matrix differs at {path}")
    return {"cases": len(cases), "successful_action_cases": sum(1 for x in cases
            if x.get("driver", {}).get("result", {}).get("terminal_status") == "OPTIMALITY_CERTIFIED")}


def validate_directed(root):
    base = root / "directed"
    campaign_dir = base / "campaign"
    report = read(campaign_dir / "directed_campaign_report.json")
    need(report.get("status") == "PASSED", "directed campaign did not PASS")
    normal, faults = report.get("normal_cases", []), report.get("fault_cases", [])
    need(len(normal) == 4 and len(faults) == 4, "directed campaign expected 4 normal + 4 fault cases")
    want_normal = {("C3-T4", m, "OPTIMALITY_CERTIFIED") for m in METHODS}
    want_normal.add(("D1-1", "FULL", "INFEASIBLE_CERTIFIED"))
    seen_normal = set()
    for item in normal:
        pair = tuple(item["target"])
        triple = (pair[0], pair[1], item["terminal_status"])
        need(triple in want_normal and item.get("status") == "PASSED",
             "directed normal cell mismatch")
        seen_normal.add(triple)
        need(item.get("new_method_workers") == 1 and item.get("resume_method_workers") == 0,
             "directed commit/resume worker count mismatch")
        campaign_report = read(Path(item["campaign_report"]))
        need(campaign_report.get("status") == "PASSED" and campaign_report.get("new_method_workers") == 1
             and campaign_report.get("resume_method_workers") == 0 and campaign_report.get("delivered_row_unchanged") is True,
             "directed campaign commit/resume/readback failed")
    need(seen_normal == want_normal, "directed normal target set differs")
    modes = {x["mode"] for x in faults}
    need(modes == {"late_delivery", "crash", "watchdog", "watchdog_cooperative"},
         "directed lifecycle fault mode set changed")
    for item in faults:
        mode = item["mode"]
        expected = "INFRASTRUCTURE_FAILURE" if mode == "crash" else "TIMEOUT"
        need(item.get("terminal_status") == expected, f"directed {mode}: wrong terminal")
        capture = read(campaign_dir / f"{ANCHORS[0]}__FULL__{mode}.capture.json")["value"]
        check_no_claims(capture, expected, "directed/" + mode)
        if mode in ("watchdog", "watchdog_cooperative"):
            need(item.get("actual_wall_seconds", 0) >= 195, f"directed {mode}: watchdog did not wait 195 seconds")
            need(item.get("child_exitcode") == (-9 if mode == "watchdog" else 0),
                 f"directed {mode}: watchdog exit code mismatch")
    neg = read(base / "negatives" / "negative_report.json")
    need(neg.get("status") == "PASSED" and neg.get("actual_workers") == 0
         and neg.get("accepted_source_mutated") is False, "directed negative report not clean")
    for label in ("wrong_exact_cost_rehashed_row", "corrupt_rehashed_certificate", "stale_backend_version"):
        result = read(base / "negatives" / label / "negative_rejection.json")
        need(result.get("status") == "REJECTED", f"negative publication gate accepted: {label}")
    need(read(base / "negatives" / "partial_files" / "partial_files_rejection.json").get("status") == "REJECTED",
         "partial publication gate did not reject")
    need(read(base / "negatives" / "incomplete_dispatch" / "retry_refusal.json").get("status") == "REJECTED",
         "incomplete dispatch retry was not refused")
    need(read(base / "negatives" / "stale_restore" / "stale_restore_rejection.json").get("status") == "REJECTED",
         "stale restore identity was accepted")
    return {"normal_cases": len(normal), "fault_cases": len(faults), "negative_cases": len(neg.get("checks", []))}


def validate_interruption(old_root, observation_root, old_report):
    obs = read(observation_root / "interruption_observation.json")
    need(obs.get("status") == "INTERRUPTED_WITHOUT_EXIT_CODE"
         and obs.get("original_directory_resumed") is False,
         "interruption evidence does not preserve original namespace")
    expected = obs.get("original_inventory")
    need(isinstance(expected, dict) and expected, "interruption inventory missing")
    actual = directory_manifest(old_root)
    need(actual == expected, "original interrupted namespace inventory changed")
    bfull = old_root / "main" / "B-D-BRANCH-S2_FULL"
    need((bfull / "dispatch_reference.json").is_file()
         and not (bfull / "reference" / "result.json").exists(),
         "original incomplete B/FULL dispatch gained a verdict")
    need(old_report.get("status") == "RUNNING" and len(old_report.get("cells", [])) == 3,
         "interrupted report no longer records the original incomplete state")
    return {"inventory_files": len(actual), "incomplete_dispatch": "B-D-BRANCH-S2/FULL/reference", "verdict": "ABSENT"}


def validate_history(history, final_root, old_root, old_source):
    hmain = history / "main"
    hzero = history / "synthetic-zero"
    hist_plan, hist_report, hist_cells, _, hist_frozen = validate_comparison(
        history, "main", 13, OLD_HEAD)
    hist_zero_plan, hist_zero_report, hist_zero_cells, _, hist_zero_frozen = validate_comparison(
        history, "synthetic-zero", 3, OLD_HEAD)
    hist_binding = read(hmain / "backend_binding.json")
    final_binding = read(final_root / "main" / "backend_binding.json")
    need(hist_binding.get("binding_id") != final_binding.get("binding_id"),
         "history and final runs unexpectedly share a binding identity")
    core = read(history / "core_readback.json")
    need(core.get("status") == "PASSED", "historical core_readback.json is not PASSED")
    lifecycle = read(history / "lifecycle" / "lifecycle.json")
    failed = [c for c in lifecycle.get("cases", []) if c.get("status") == "FAILED"]
    failures = lifecycle.get("failures", [])
    need(lifecycle.get("status") == "FAILED" and failed and failures,
         "historical lifecycle failure evidence was not retained")
    failed_modes = {c.get("mode") for c in failed}
    need({"late_solver", "late_certificate", "late_logging"} <= failed_modes,
         "historical lifecycle late-phase failures are missing")
    interruption = validate_interruption(old_root, history, read(old_root / "main" / "comparison.json"))
    old_source_record = check_source(old_source, hist_plan, hmain, OLD_HEAD)
    need(hist_zero_plan.get("source_closure") == hist_plan.get("source_closure"),
         "historical zero source closure differs from main")
    old_zero_source = check_source(old_source, hist_zero_plan, hzero, OLD_HEAD)
    return {"main_cells": len(hist_cells), "zero_cells": len(hist_zero_cells),
            "main_workers": 26, "zero_workers": 6,
            "old_binding_id": hist_binding.get("binding_id"),
            "core_readback": core.get("status"),
            "lifecycle_status": lifecycle.get("status"),
            "retained_lifecycle_failures": len(failed), "failed_modes": sorted(failed_modes),
            "interruption": interruption, "old_source": old_source_record,
            "old_zero_source": old_zero_source,
            "frozen_inputs": {"main": hist_frozen, "zero": hist_zero_frozen}}


def validate_runtime_provenance(root, source, plan):
    artifact = read(root / "provenance.json")
    need(artifact.get("status") == "PASSED" and artifact.get("ros_distro") == "humble",
         "stage-0 runtime provenance missing or not ROS Humble")
    need(artifact.get("worker_calls") == 0 and artifact.get("solver_calls") == 0
         and artifact.get("dds_requests") == 0,
         "stage-0 provenance unexpectedly launched work")
    modules = artifact.get("modules")
    need(isinstance(modules, dict) and modules, "stage-0 module provenance is empty")
    expected_source_modules = {"experiments.cmr_ros2_unified_v12.runner",
                               "ltl_automaton_planner_core.ltl_tools.discrete_plan",
                               "ltl_automaton_execution.execution_node",
                               "ltl_automaton_planner.planning_graph_snapshot"}
    need(expected_source_modules <= set(modules), "stage-0 source module list is incomplete")
    for name, item in modules.items():
        path = Path(item["path"])
        need(path.is_file() and sha_file(path) == item["sha256"],
             f"stage-0 module file/hash mismatch: {name}")
    for name in expected_source_modules:
        path = Path(modules[name]["path"]).resolve()
        need(path.is_relative_to(source.resolve()), f"stage-0 module resolved outside selected source: {name}")
    relative_runner = Path(modules["experiments.cmr_ros2_unified_v12.runner"]["path"]).resolve().relative_to(source.resolve())
    need(plan["source_closure"].get(relative_runner.as_posix()) == modules["experiments.cmr_ros2_unified_v12.runner"]["sha256"],
         "stage-0 runner module does not match the frozen source closure")
    return {"ros_distro": artifact["ros_distro"], "modules_checked": len(modules),
            "source_modules": sorted(expected_source_modules)}


def validate_stage_exits(root, offline_observation):
    control = root / "control"
    launches = sorted(control.glob("*.launch.json"))
    need(launches, "no stage launch records found")
    passed, preserved_failures = [], []
    for launch in launches:
        phase = launch.name[:-len(".launch.json")]
        rc = control / (phase + ".rc")
        log = control / (phase + ".log")
        need(rc.is_file() and log.is_file(), f"stage {phase} has no exit/log artifact")
        code = rc.read_text(encoding="utf-8").strip()
        if phase == "offline":
            need(code == "1" and offline_observation.get("original_phase_rc") == 1
                 and offline_observation.get("original_failure_retained") == "control/offline.log",
                 "original offline failure/exit record was not retained exactly")
            preserved_failures.append({"phase": phase, "rc": 1,
                                       "log": "control/offline.log",
                                       "status": "FAILED_RETAINED"})
        else:
            need(code == "0", f"stage {phase} returned nonzero")
            passed.append(phase)
    need("offline-recovery" in passed,
         "offline-recovery stage did not complete successfully")
    return {"passed_stages": passed, "preserved_failed_stages": preserved_failures}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--namespace", type=Path, required=True)
    ap.add_argument("--old-namespace", type=Path, required=True)
    ap.add_argument("--source", type=Path, required=True)
    ap.add_argument("--history-namespace", type=Path,
                    default=Path("/tmp/cmr_unified_v12_44a542e_20261025_r2"))
    ap.add_argument("--history-source", type=Path,
                    default=Path("/tmp/cmr_unified_v12_source_44a542e_20261023"))
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    summary = {"schema": "cmr-unified-v12-scientific-readback-v1", "status": "RUNNING",
               "execution": "stdlib file/hash readback; no package imports or workers"}
    try:
        main_plan, main_report, main_cells, main_results, main_frozen = validate_comparison(args.namespace, "main", 13, HEAD)
        zero_plan, zero_report, zero_cells, zero_results, zero_frozen = validate_comparison(args.namespace, "synthetic-zero", 3)
        need(main_plan.get("expected_method_workers") == 26,
             "final main run is not the fresh 26-worker qualification")
        changed_rows = compare_prior_transport(args.namespace, Path("/tmp/cmr_v12_compact_cost_3cd0d16_20261023_r2"), main_cells)
        lifecycle = validate_lifecycle(args.namespace)
        dds_main = validate_dds(args.namespace / "dds")
        dds_zero = validate_dds(args.namespace / "zero-dds", zero=True)
        directed = validate_directed(args.namespace)
        offline_observation = read(args.namespace / "offline_recovery_observation.json")
        need(offline_observation.get("status") == "PASSED"
             and offline_observation.get("source_changed") is False
             and offline_observation.get("additional_worker_calls") == 0,
             "offline recovery observation did not pass without source/worker changes")
        need(offline_observation.get("original_failure_retained") == "control/offline.log"
             and offline_observation.get("original_phase_rc") == 1
             and offline_observation.get("cause") == "external stage supplied str instead of CLI Path binding",
             "offline recovery did not preserve original failure provenance")
        need((args.namespace / "offline").is_dir(),
             "original failed offline directory was not retained")
        recovery_dir = Path(offline_observation.get("qualified_directory", ""))
        expected_recovery = (args.namespace / "offline_recovery").resolve()
        if not recovery_dir.is_absolute() or not recovery_dir.exists():
            recovery_dir = expected_recovery
        need(recovery_dir.resolve() == expected_recovery,
             "offline recovery proof points outside the final namespace")
        offline = read(recovery_dir / "offline_chain_evidence.json")
        need(offline.get("status") == "PASSED", "offline recovery evidence is not PASSED")
        need(offline.get("analysis", {}).get("rows") == 510 and offline.get("analysis", {}).get("tables") == 16,
             "offline fixture analysis is not 510 rows/16 tables")
        need(offline.get("real_results") == 0 and offline.get("planner_calls") == 0
             and offline.get("provider_calls") == 0 and offline.get("dds_calls") == 0,
             "offline fixture contains real execution calls")
        stages = validate_stage_exits(args.namespace, offline_observation)
        source = check_source(args.source, main_plan, args.namespace / "main")
        # Both profiles bind the same source closure; verify copied source snapshots in zero too.
        need(zero_plan.get("source_closure") == main_plan.get("source_closure"), "zero profile source closure differs")
        zero_source = check_source(args.source, zero_plan, args.namespace / "synthetic-zero")
        history = validate_history(args.history_namespace, args.namespace, args.old_namespace, args.history_source)
        provenance = validate_runtime_provenance(args.namespace, args.source, main_plan)
        summary.update(status="PASSED", head=HEAD, main_cells=len(main_cells),
            main_qualified_deliveries=26, main_workers={"fresh": 26, "carried": 0},
            zero_cells=len(zero_cells), zero_qualified_deliveries=6,
            source_closure={"main": source, "zero": zero_source},
            frozen_inputs={"main": main_frozen, "zero": zero_frozen},
            normalized_prior_transport=changed_rows,
            lifecycle=lifecycle, dds={"main": dds_main, "zero": dds_zero},
            directed=directed,
            offline={"status": offline["status"], "rows": offline["analysis"]["rows"],
                     "tables": offline["analysis"]["tables"], "real_results": 0,
                     "recovery_observation": offline_observation,
                     "preserved_failed_stage": stages["preserved_failed_stages"],
                     "original_failure_cause": offline_observation["cause"]},
            historical=history, runtime_provenance=provenance,
            no_package_imports=True, actual_worker_counts_exclude_directed_negative_replays=True)
        summary["completed_stages"] = stages
    except Exception as error:
        summary.update(status="FAILED", error=f"{type(error).__name__}: {error}")
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(json.dumps({"status": "FAILED", "output": str(args.output), "error": summary["error"]}), file=sys.stderr)
        return 1
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASSED", "output": str(args.output)}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
