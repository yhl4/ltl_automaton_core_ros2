#!/usr/bin/env python3
"""Run bounded V12 campaign qualification and isolated rejection controls.

Invoke from the prepared Linux environment with the V12 source checkout on
PYTHONPATH. The campaign phase launches only the explicitly listed methods;
the negatives phase reuses captured attempt bytes and launches no worker.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import shutil
import sys
import traceback
from pathlib import Path
from types import SimpleNamespace


def _raw(value):
    from experiments.cmr_ros2_search_entry import publication_v7 as helpers
    return helpers.raw(value)


def _sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _write(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_bytes(_raw(value))


def _rehash_row(row):
    from experiments.cmr_ros2_search_entry import publication_v7 as helpers
    row.pop('result_hash', None)
    row['result_hash'] = helpers.digest(
        helpers.metadata.canonical(row).encode('utf-8'))


def _args(base, output, cell):
    return SimpleNamespace(plan=base.plan, binding=base.binding,
        kernel_root=base.kernel_root, output=Path(output), backend='ros2-v12',
        instance_id=cell[0], method=cell[1])


def _capture_candidate(fn, capture):
    from experiments.cmr_ros2_unified_v12 import runner
    original = runner.candidate_isolated

    def wrapped(worker_args, plan, cell, output, *, backend_name='ros2-v12'):
        value = original(worker_args, plan, cell, output, backend_name=backend_name)
        capture.update(value=value, attempt_directory=str(output))
        return value

    runner.candidate_isolated = wrapped
    try:
        return fn()
    finally:
        runner.candidate_isolated = original


def campaign_phase(args):
    from experiments.cmr_ros2_unified_v12 import campaign, runner, lifecycle

    output = args.output / 'campaign'
    output.mkdir(parents=True, exist_ok=False)
    plan = runner.load_plan(args.plan)
    cells = [('C3-T4', method) for method in runner.METHODS]
    cells.append(('D1-1', 'FULL'))
    report = {'schema': 'cmr-v12-directed-qualification-v1',
              'status': 'RUNNING', 'normal_cases': [], 'fault_cases': [],
              'method_workers_are_child_processes': True}
    for instance, method in cells:
        key = f'{instance}__{method}'
        case_args = _args(args, output / key, (instance, method))
        captured = {}
        case = _capture_candidate(lambda: campaign.qualify(case_args), captured)
        expected = 'INFEASIBLE_CERTIFIED' if instance == 'D1-1' else 'OPTIMALITY_CERTIFIED'
        if case.get('status') != 'PASSED' or case['committed']['terminal_status'] != expected:
            raise AssertionError(f'normal campaign qualification failed: {key}')
        _write(output / f'{key}.capture.json',
               {'value': captured['value'], 'attempt_directory': captured['attempt_directory']})
        report['normal_cases'].append({'target': [instance, method], 'status': 'PASSED',
            'terminal_status': case['committed']['terminal_status'],
            'new_method_workers': case['new_method_workers'],
            'resume_method_workers': case['resume_method_workers'],
            'campaign_report': str(case_args.output / 'campaign_report.json')})

    fault_modes = ('late_delivery', 'crash', 'watchdog', 'watchdog_cooperative')
    fault_cell = ('A-T1-M0-A-S-BRANCH', 'FULL')
    for mode in fault_modes:
        key = f'{fault_cell[0]}__{fault_cell[1]}__{mode}'
        case_args = _args(args, output / key, fault_cell)
        captured = {}
        original = lifecycle.run_fault

        def capture_fault(*pos, **kw):
            value = original(*pos, **kw)
            captured.update(value=value, attempt_directory=str(pos[5]))
            return value

        lifecycle.run_fault = capture_fault
        try:
            try:
                case = campaign.qualify_fault(case_args, mode)
                rejected = False
            except Exception as error:
                case, rejected = None, True
                rejection = f'{type(error).__name__}: {error}'
        finally:
            lifecycle.run_fault = original
        if not captured:
            raise AssertionError(f'lifecycle fault did not yield an attempt: {mode}')
        expected = 'INFRASTRUCTURE_FAILURE' if mode == 'crash' else 'TIMEOUT'
        lifecycle.no_claims(captured['value'], expected)
        if mode == 'crash':
            if not rejected or (case_args.output / 'completed').exists():
                raise AssertionError('crash result was published or not rejected')
        elif rejected or case.get('status') != 'PASSED' or case['committed']['terminal_status'] != 'TIMEOUT':
            raise AssertionError(f'timeout campaign publication failed: {mode}')
        _write(output / f'{key}.capture.json',
               {'value': captured['value'], 'attempt_directory': captured['attempt_directory']})
        report['fault_cases'].append({'target': list(fault_cell), 'mode': mode,
            'status': 'REJECTED_AS_INFRASTRUCTURE' if mode == 'crash' else 'PUBLISHED_TIMEOUT',
            'rejection': rejection if rejected else None,
            'actual_wall_seconds': captured['value']['fault_qualification']['actual_wall_seconds'],
            'terminal_status': captured['value']['row']['terminal_status'],
            'child_exitcode': captured['value']['worker_exitcode']})
    report['status'] = 'PASSED'
    _write(output / 'directed_campaign_report.json', report)
    return report


def _copy_candidate(source_value, source_attempt, mutation):
    from experiments.cmr_ros2_unified_v12 import runner
    original = runner.candidate_isolated

    def replay(_args, _plan, _cell, output, *, backend_name='ros2-v12'):
        shutil.copytree(source_attempt, output)
        value = copy.deepcopy(source_value)
        value['worker_pid'] = 2147483647
        value['worker_alive_after_cleanup'] = False
        mutation(value, Path(output))
        return value

    runner.candidate_isolated = replay
    return original


def _negative_publication(base, output, source_value, source_attempt, label, mutate):
    from experiments.cmr_ros2_unified_v12 import campaign, runner
    case_args = _args(base, output, ('C3-T4', 'FULL'))
    instance = campaign.Campaign(case_args)
    original = _copy_candidate(source_value, source_attempt, mutate)
    try:
        try:
            instance.run_cell()
        except Exception as error:
            if (instance.root / 'completed' / instance.cell['cell_id']).exists():
                raise AssertionError(f'{label} reached scientific publication') from error
            _write(instance.root / 'negative_rejection.json',
                   {'label': label, 'status': 'REJECTED',
                    'error': f'{type(error).__name__}: {error}',
                    'method_workers_launched': 0})
        else:
            raise AssertionError(f'invalid publication was accepted: {label}')
    finally:
        runner.candidate_isolated = original


def _replace_identity(value, key, stale):
    if isinstance(value, dict):
        for name, item in list(value.items()):
            if name == key:
                value[name] = stale
            else:
                _replace_identity(item, key, stale)
    elif isinstance(value, list):
        for item in value:
            _replace_identity(item, key, stale)


def _stale_restore(base, output, source_value, source_attempt):
    from experiments.cmr_ros2_unified_v12 import campaign, runner
    case_args = _args(base, output, ('C3-T4', 'FULL'))
    instance = campaign.Campaign(case_args)
    original = _copy_candidate(source_value, source_attempt, lambda value, _dst: None)
    try:
        instance.run_cell()
    finally:
        runner.candidate_isolated = original

    folder = instance.root / 'completed' / instance.cell['cell_id']
    row = json.loads((folder / 'validated_result.json').read_bytes())
    _replace_identity(row, 'version_binding_id', 'STALE-RESTORE-VERSION')
    for round_row in row.get('rounds') or []:
        round_row['version_binding_id'] = 'STALE-RESTORE-VERSION'
    _rehash_row(row)
    _write(folder / 'validated_result.json', row)
    envelope_path = folder / 'result.json'
    envelope = json.loads(envelope_path.read_bytes())
    envelope['worker_result'] = row
    _write(envelope_path, envelope)
    (folder / 'rounds.jsonl').write_bytes(b''.join(_raw(r) for r in row.get('rounds') or []))

    record_path, ledger_path = folder / 'pilot_record.json', folder / 'ledger_entry.json'
    record, ledger = json.loads(record_path.read_bytes()), json.loads(ledger_path.read_bytes())
    _replace_identity(record, 'version_binding_id', 'STALE-RESTORE-VERSION')
    _replace_identity(ledger, 'version_binding_id', 'STALE-RESTORE-VERSION')
    if 'validated_result_hash' in record:
        record['validated_result_hash'] = row['result_hash']
    if 'worker_result' in record:
        record['worker_result'] = row
    ledger['validated_result_hash'] = row['result_hash']
    if 'record_payload_sha256' in ledger:
        from experiments.cmr_ros2_search_entry import publication_v7 as helpers
        ledger['record_payload_sha256'] = helpers.digest(_raw(
            {k: v for k, v in record.items() if k != 'ledger_commit_sha256'}))
    if 'validated_input_file_hashes' in ledger:
        ledger['validated_input_file_hashes'] = {
            name: _sha(folder / name) for name in ledger['validated_input_file_hashes']}
    if 'ledger_commit_sha256' in record:
        from experiments.cmr_ros2_search_entry import publication_v7 as helpers
        record['ledger_commit_sha256'] = helpers.digest(_raw(ledger))
    _write(record_path, record)
    _write(ledger_path, ledger)
    manifest_path = folder / 'commit_manifest.json'
    manifest = json.loads(manifest_path.read_bytes())
    manifest = {name: _sha(folder / name) for name in manifest}
    _write(manifest_path, manifest)
    (instance.root / 'core_results.jsonl').write_bytes(_raw(record))
    (instance.root / 'ledger.jsonl').write_bytes(_raw(ledger))

    resume_args = _args(base, instance.root, ('C3-T4', 'FULL'))
    try:
        campaign.Campaign(resume_args, resume=True)
    except Exception as error:
        if not any(token in str(error).lower() for token in ('version_binding', 'descriptor', 'identity')):
            raise AssertionError('stale restore failed before its identity guard: ' + str(error)) from error
        _write(instance.root / 'stale_restore_rejection.json',
               {'status': 'REJECTED', 'error': f'{type(error).__name__}: {error}',
                'accepted_source_mutated': False})
    else:
        raise AssertionError('stale version identity was accepted during restore')


def negatives_phase(args):
    from experiments.cmr_ros2_unified_v12 import campaign, runner
    from experiments.cmr_ros2_search_entry import publication_v7 as helpers

    source_file = args.output / 'campaign' / 'C3-T4__FULL.capture.json'
    source = json.loads(source_file.read_bytes())
    source_value = source['value']
    source_attempt = Path(source['attempt_directory'])
    if not source_attempt.is_dir():
        raise FileNotFoundError('captured positive attempt directory missing')
    output = args.output / 'negatives'
    output.mkdir(parents=True, exist_ok=False)

    def wrong_objective(value, _attempt):
        value['row']['objective'] = '13'
        _rehash_row(value['row'])

    def bad_certificate(value, attempt):
        row = value['row']
        path = attempt / 'certificates' / row['certificate_path']
        cert = json.loads(path.read_bytes())
        cert['objective'] = '13'
        data = _raw(cert)
        path.write_bytes(data)
        row['objective'] = '13'
        row['certificate_hash'] = hashlib.sha256(data).hexdigest()
        _rehash_row(row)

    def stale_version(value, _attempt):
        _replace_identity(value['row'], 'version_binding_id', 'STALE-PUBLICATION-VERSION')
        for round_row in value['row'].get('rounds') or []:
            round_row['version_binding_id'] = 'STALE-PUBLICATION-VERSION'
        _rehash_row(value['row'])

    for label, mutation in (('wrong_exact_cost_rehashed_row', wrong_objective),
                            ('corrupt_rehashed_certificate', bad_certificate),
                            ('stale_backend_version', stale_version)):
        _negative_publication(args, output / label, source_value, source_attempt,
                              label, mutation)

    partial_args = _args(args, output / 'partial_files', ('C3-T4', 'FULL'))
    partial = campaign.Campaign(partial_args)
    destination = partial.root / 'completed' / partial.cell['cell_id']
    partial.state.campaign.current = partial.cell
    try:
        try:
            partial.coordinator.Campaign.publication_gate(
                partial.state.campaign, destination, {})
        except Exception as error:
            if destination.exists():
                raise AssertionError('partial files created a committed cell') from error
            _write(partial.root / 'partial_files_rejection.json',
                   {'status': 'REJECTED', 'error': f'{type(error).__name__}: {error}'})
        else:
            raise AssertionError('partial publication file set was accepted')
    finally:
        partial.state.campaign.current = None

    retry_args = _args(args, output / 'incomplete_dispatch', ('C3-T4', 'FULL'))
    retry = campaign.Campaign(retry_args)
    (retry.root / 'dispatch.json').write_text('prior dispatch\n', encoding='utf-8')
    calls = {'candidate': 0}
    original = runner.candidate_isolated

    def should_not_dispatch(*_pos, **_kw):
        calls['candidate'] += 1
        raise AssertionError('candidate hook must not run')

    runner.candidate_isolated = should_not_dispatch
    try:
        try:
            retry.run_cell()
        except Exception as error:
            if calls['candidate'] or 'automatic retry forbidden' not in str(error):
                raise AssertionError('incomplete dispatch did not fail closed') from error
            _write(retry.root / 'retry_refusal.json',
                   {'status': 'REJECTED', 'candidate_calls': calls['candidate'],
                    'error': str(error)})
        else:
            raise AssertionError('incomplete dispatch was retried')
    finally:
        runner.candidate_isolated = original

    _stale_restore(args, output / 'stale_restore', source_value, source_attempt)
    report = {'schema': 'cmr-v12-directed-negatives-v1', 'status': 'PASSED',
              'checks': ['wrong_exact_cost_rehashed_row', 'corrupt_rehashed_certificate',
                         'stale_backend_version', 'partial_files',
                         'incomplete_dispatch_retry_refusal', 'stale_restore_version'],
              'actual_workers': 0, 'accepted_source_mutated': False}
    _write(output / 'negative_report.json', report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--kernel-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--phase', choices=('campaign', 'negatives'), required=True)
    args = parser.parse_args(argv)
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=True)
    try:
        report = campaign_phase(args) if args.phase == 'campaign' else negatives_phase(args)
        print(json.dumps({'status': report['status'], 'phase': args.phase,
                          'output': str(args.output)}, sort_keys=True))
        return 0
    except Exception as error:
        _write(args.output / f'{args.phase}_fatal.json',
               {'status': 'FAILED', 'error': f'{type(error).__name__}: {error}',
                'traceback': traceback.format_exc()})
        print(f'{type(error).__name__}: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
