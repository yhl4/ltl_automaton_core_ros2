"""Sequential remaining stages; never overwrite a prior launch or result."""
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path('/tmp/cmr_unified_v12_44a542e_20261025_r2')
control=root/'control'
env=Path(__file__).with_name('env_complete.sh')
for prerequisite in ('core-continue','zero-prepare','zero-core'):
    result_path=control/(prerequisite+'.rc')
    while not result_path.exists():
        time.sleep(2)
    if result_path.read_text().strip()!='0':
        raise SystemExit('prerequisite failed: '+prerequisite)
for phase in sys.argv[1:]:
    with (control/(phase+'.launch.json')).open('x') as stream:
        json.dump(dict(phase=phase,start_ns=time.time_ns(),command=['bash',str(env),phase]),stream)
    with (control/(phase+'.log')).open('w') as log:
        result=subprocess.run(['bash',str(env),phase],stdout=log,stderr=subprocess.STDOUT)
    (control/(phase+'.rc')).write_text(str(result.returncode)+'\n')
    if result.returncode:
        raise SystemExit(result.returncode)
