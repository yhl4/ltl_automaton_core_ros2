#!/bin/bash
set -e
source /opt/ros/humble/setup.bash
source /tmp/ltl_ros2_combo_bd75495/install/setup.bash
export PYTHONDONTWRITEBYTECODE=1
export CMR_CODE=/tmp/cmr_unified_v12_source_d796533_20261025
export CMR_OUT=/tmp/cmr_unified_v12_d796533_20261025_r3
export CMR_KERNEL=/mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel
export CMR_RECEIPT=/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json
cd "$CMR_CODE"
export PYTHONPATH="$CMR_CODE/ltl_automaton_execution:$CMR_CODE/ltl_automaton_planner:$CMR_CODE/ltl_automaton_planner_core:$CMR_CODE:$CMR_KERNEL:$PYTHONPATH"
exec python3 -u /mnt/c/Users/Yuhling/.codex/worktrees/v7-audit-dds-regression/unified_v12_20261023/stage_r3.py "$@"
