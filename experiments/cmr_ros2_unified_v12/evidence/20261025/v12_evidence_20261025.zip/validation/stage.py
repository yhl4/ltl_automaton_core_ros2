"""Sequential isolated qualification stages; every stage has its own artifacts."""
import argparse
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

from experiments.cmr_ros2_unified_v12 import runner


def args_for(profile='main'):
    output=Path(os.environ['CMR_OUT'])/profile
    return SimpleNamespace(binding=os.environ['CMR_RECEIPT'],kernel_root=os.environ['CMR_KERNEL'],
        output=output,profile=profile,plan=output/'plan.json',version_binding=output/'backend_binding.json')


def boundary(args,output):
    from experiments.cmr_ros2_unified_v12 import lifecycle
    plan=runner.load_plan(args.plan)
    checks=[]; start=1_000_000_000
    for name in ('A-T1-M0-A-S-BRANCH','D1-1'):
        sample=json.loads((args.output/(name+'_FULL')/'ros2-v12/result.json').read_bytes())['row']
        for elapsed in (179_999_999_999,180_000_000_000,180_000_000_001,195_000_000_000):
            row=copy.deepcopy(sample)
            row.update(method_start_ns=start,terminal_completion_ns=start+100,qualified_runner_completion_ns=start+100)
            runner.original.terminal_delivery(row,start+elapsed,outer_start=start)
            if elapsed>=180_000_000_000:
                lifecycle.no_claims(dict(row=row,transport=None),'TIMEOUT')
            elif row['terminal_status']!=sample['terminal_status']:
                raise AssertionError('early verdict changed')
            checks.append(dict(instance=name,elapsed_ns=elapsed,status='PASSED'))
    formal,_,_,_=runner.authority(plan,args.binding,args.kernel_root)
    entry=runner.AttemptEntry(args.plan)
    entry.configure(formal,'ros2-v12',entry.binding_path)
    request=entry.request('ros2-v12',plan['cells'][0])
    for stage,elapsed in (('planner',180_000_000_000),('outer_watchdog',195_000_000_000),('infrastructure',100)):
        row=formal.timeout_serialization(request,stage,method_start_ns=start,terminal_completion_ns=start+elapsed)
        runner.original.terminal_delivery(row,start+elapsed,outer_start=start,forced_timeout=stage=='outer_watchdog')
        lifecycle.no_claims(dict(row=row,transport=None),'INFRASTRUCTURE_FAILURE' if stage=='infrastructure' else 'TIMEOUT')
        checks.append(dict(stage=stage,status='PASSED'))
    runner.write(output,dict(status='PASSED',simulated_clock=True,checks=checks,count=len(checks),new_workers=0))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('stage')
    mode=parser.parse_args().stage
    root=Path(os.environ['CMR_OUT']);root.mkdir(exist_ok=True)
    args=args_for('synthetic-zero' if mode.startswith('zero') else 'main')
    if mode in ('prepare','zero-prepare'):
        runner.prepare(args)
    elif mode in ('core','zero-core'):
        runner.run(args)
    elif mode=='lifecycle':
        from experiments.cmr_ros2_unified_v12 import lifecycle
        boundary(args,root/'boundary.json')
        lifecycle.MODES=tuple(m for m in lifecycle.MODES if not m.startswith('watchdog'))
        args.instance_id=runner.ANCHORS[0];args.method=None
        result=lifecycle.run(args,runner.load_plan(args.plan),root/'lifecycle')
        if result['status']!='PASSED':
            raise AssertionError('lifecycle qualification failed')
    elif mode in ('dds','zero-dds'):
        from experiments.cmr_ros2_unified_v12 import dds
        result=dds.run_dds(args,runner.load_plan(args.plan),root/mode)
        if result['status']!='PASSED':
            raise AssertionError('DDS qualification failed')
    elif mode=='feedback':
        env=dict(os.environ,ROS_DOMAIN_ID='234',ROS_LOCALHOST_ONLY='1')
        command=[sys.executable,'-B','-m','pytest','-q',
            'experiments/cmr_ros2_integration/test_feedback.py',
            'experiments/cmr_ros2_integration/test_feedback_dds.py']
        result=subprocess.run(command,env=env)
        if result.returncode:
            raise SystemExit(result.returncode)
    elif mode=='offline':
        from experiments.cmr_ros2_unified_v12 import offline_chain
        args.output=root/'offline'
        offline_chain.run(args)
    elif mode in ('campaign','negatives'):
        helper=Path(__file__).with_name('directed_qualification.py')
        subprocess.run([sys.executable,'-B',str(helper),'--phase',mode,'--plan',str(args.plan),
            '--binding',str(args.binding),'--kernel-root',str(args.kernel_root),
            '--output',str(root/mode)],check=True)
    else:
        raise ValueError(mode)


if __name__=='__main__':
    main()
