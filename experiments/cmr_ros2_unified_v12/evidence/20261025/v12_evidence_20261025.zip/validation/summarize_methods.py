"""Summarize completed method records and operation counters without solving."""
import json
from pathlib import Path

root=Path(r'\\wsl.localhost\Ubuntu-22.04-D\tmp\cmr_unified_v12_d796533_20261025_r3')
result={}
for profile in ('main','synthetic-zero'):
    report=json.loads((root/profile/'comparison.json').read_bytes())
    cells=report['cells']
    rows=[v['row'] for c in cells for v in c['backends'].values()]
    result[profile]=dict(status=report['status'],cells=len(cells),qualified_records=len(rows),
        recorded_rounds=sum(len(r.get('rounds') or []) for r in rows),
        feasible_records=sum(r['terminal_status']=='OPTIMALITY_CERTIFIED' for r in rows),
        exact_empty_records=sum(r['terminal_status']=='INFEASIBLE_CERTIFIED' for r in rows),
        additional_replays=sum(x.get('status')=='PASS' for c in cells for x in c['certificate_replays'].values()),
        frozen_inputs=len(json.loads((root/profile/'frozen_inputs_before.json').read_bytes())))
    if profile=='main':
        result['representative_counts']={}
        for cell in cells:
            if (cell['instance_id'],cell['method']) not in (('C3-T4','AP-D'),('D3-1','AP-D')):
                continue
            value=cell['backends']['ros2-v12']
            counts={}
            for item in value['build_work']+value['search_work']:
                for key,number in item.items():
                    if (type(number) is int and key not in ('full_ts_source_states','full_ts_source_edges')
                            and any(text in key for text in ('full_ts','projection','witness','suffix_graph','exact_cost','compact_cost'))):
                        counts[key]=counts.get(key,0)+number
            result['representative_counts'][cell['instance_id']]=counts
output=Path(__file__).with_name('method_summary_d796.json')
output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result))
