"""Qualify the corrected fault harness before dispatching the final matrix."""
import os
from pathlib import Path
import sys

import stage
from experiments.cmr_ros2_unified_v12 import runner

mode=sys.argv[1]
if mode=='offline-recovery':
    from experiments.cmr_ros2_unified_v12 import offline_chain
    args=stage.args_for()
    args.binding=Path(args.binding)
    args.output=Path(os.environ['CMR_OUT'])/'offline_recovery'
    report=offline_chain.run(args)
    runner.write(Path(os.environ['CMR_OUT'])/'offline_recovery_observation.json',
        dict(status=report['status'],qualified_directory=str(args.output),
             original_failure_retained='control/offline.log',original_phase_rc=1,
             cause='external stage supplied str instead of CLI Path binding',
             additional_worker_calls=0,source_changed=False))
elif mode=='lifecycle':
    from experiments.cmr_ros2_unified_v12 import lifecycle
    args=stage.args_for()
    args.instance_id=runner.ANCHORS[0];args.method=None
    lifecycle.MODES=tuple(m for m in lifecycle.MODES if not m.startswith('watchdog'))
    result=lifecycle.run(args,runner.load_plan(args.plan),Path(os.environ['CMR_OUT'])/'lifecycle')
    if result['status']!='PASSED':
        raise AssertionError('corrected lifecycle qualification failed')
elif mode=='boundary':
    stage.boundary(stage.args_for(),Path(os.environ['CMR_OUT'])/'boundary.json')
elif mode in ('prepare','core','zero-prepare','zero-core'):
    stage.main()
else:
    path=Path(__file__).with_name('stage_complete.py')
    exec(compile(path.read_text(),str(path),'exec'))
