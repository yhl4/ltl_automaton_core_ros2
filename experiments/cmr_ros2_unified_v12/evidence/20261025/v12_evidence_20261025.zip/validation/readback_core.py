"""Early stdlib readback of completed method evidence; no planning calls."""
import json
from pathlib import Path
import runpy

module=runpy.run_path(str(Path(__file__).with_name('scientific_readback.py')))
root=Path('/tmp/cmr_unified_v12_44a542e_20261025_r2')
result={'status':'RUNNING','solver_calls':0,'verifier_calls':0}
try:
    plan,report,cells,values,frozen=module['validate_comparison'](root,'main',13)
    prior=module['compare_prior_transport'](root,Path('/tmp/cmr_v12_compact_cost_3cd0d16_20261023_r2'),cells)
    source=module['check_source'](Path('/tmp/cmr_unified_v12_source_44a542e_20261023'),plan,root/'main')
    result.update(status='PASSED',cells=len(cells),qualified_records=len(values),frozen=frozen,prior=prior,source=source)
except Exception as error:
    result.update(status='FAILED',error=repr(error))
finally:
    (root/'core_readback.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result))
if result['status']!='PASSED':
    raise SystemExit(1)
