"""Run the unchanged archive checks beside the WSL originals, avoiding UNC I/O."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

import verify_archive as checks


def mapped_path(value):
    raw = str(value)
    match = re.match(r"^\\\\(?:wsl\.localhost|wsl\$)\\([^\\]+)(.*)$", raw, re.I)
    if match:
        distro, suffix = match.groups()
        if distro != "Ubuntu-22.04-D":
            raise ValueError("Unexpected evidence distro: " + distro)
        return Path("/" + suffix.replace("\\", "/").lstrip("/"))
    match = re.match(r"^([A-Za-z]):[\\/](.*)$", raw)
    if match:
        drive, suffix = match.groups()
        return Path("/mnt/" + drive.lower() + "/" + suffix.replace("\\", "/"))
    return Path(value)


def main():
    # All assertions in verify_archive.main remain enabled. Only filesystem
    # spelling is translated; original bytes and native Linux links are read.
    checks.Path = mapped_path
    evidence = mapped_path(sys.argv[sys.argv.index("--evidence") + 1])
    source = mapped_path(sys.argv[sys.argv.index("--repo") + 1])
    head = subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip()
    if head != "d79653300e7bed556a4d1583562e09f3c1dd6f88":
        raise ValueError("Unexpected verification source checkout")
    checks.main()
    proof_path = evidence / "root_archive_readback.json"
    proof = json.loads(proof_path.read_bytes())
    proof["readback_environment"] = {
        "platform": "WSL Ubuntu-22.04-D", "git_source": str(source),
        "source_head": head, "original_path_mapping": "UNC/drive to same WSL files or mounted drives",
        "archive_checks_unchanged": True,
    }
    proof_path.write_text(json.dumps(proof, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    index_path = evidence / "index.json"
    index = json.loads(index_path.read_bytes())
    index["archive_readback"].update(size=proof_path.stat().st_size,
        sha256=hashlib.sha256(proof_path.read_bytes()).hexdigest())
    index_path.write_text(json.dumps(index, indent=2, sort_keys=True) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
