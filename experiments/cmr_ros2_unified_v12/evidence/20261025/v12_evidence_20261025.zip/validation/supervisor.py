"""Run requested qualification stages sequentially and retain every exit code."""
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path('/tmp/cmr_unified_v12_44a542e_20261023')
control=root/'control';control.mkdir(exist_ok=True)
env=Path(__file__).with_name('env_r1.sh')
for phase in sys.argv[1:]:
    marker=control/(phase+'.launch.json')
    with marker.open('x') as stream:
        json.dump(dict(phase=phase,start_ns=time.time_ns(),command=['bash',str(env),phase]),stream)
    with (control/(phase+'.log')).open('w') as log:
        result=subprocess.run(['bash',str(env),phase],stdout=log,stderr=subprocess.STDOUT)
    (control/(phase+'.rc')).write_text(str(result.returncode)+'\n')
    if result.returncode:
        raise SystemExit(result.returncode)
