#!/usr/bin/env python3
"""Package final V12 evidence without modifying source/runtime inputs."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tempfile
import zipfile

EXPECTED_HEAD = "d79653300e7bed556a4d1583562e09f3c1dd6f88"
HISTORICAL_HEAD = "44a542e741b0dda258364ffe3ec27ab4d799852a"
SOURCE_FILES = tuple(
    f"experiments/cmr_ros2_unified_v12/{name}"
    for name in ("backend.py", "runner.py", "fixtures.py", "offline_chain.py",
                 "dds.py", "lifecycle.py", "campaign.py")
)
VALIDATION_SUFFIXES = {
    ".py", ".sh", ".json", ".log", ".rc", ".bundle", ".txt", ".md",
    ".toml", ".yaml", ".yml", ".diff", ".patch"
}
SENSITIVE_MARKERS = ("credential", "secret", "token", "apikey", "api_key", ".env")
SENSITIVE_VALUE = re.compile(
    rb"(?i)(?:api[_-]?key|access[_-]?token|password|secret)\s*[\"']?\s*[:=]\s*[\"']?([A-Za-z0-9+/=_-]{16,})"
)
TEXT_SUFFIXES = {".json", ".log", ".txt", ".py", ".sh", ".rc", ".md", ".toml", ".yaml", ".yml"}
LX_SYMLINK_REPARSE_TAG = 0xA000001D
PACKAGING_FAILURE_OBSERVATION = {
    "status": "FAILED",
    "error": "OSError Errno22 while opening a WSL UNIX symlink through Windows UNC",
    "wsl_link": "/tmp/cmr_unified_v12_d796533_20261025_r3/feedback_artifacts/test_dds_repeated_targets_rejecurrent",
    "wsl_target": "/tmp/cmr_unified_v12_d796533_20261025_r3/feedback_artifacts/test_dds_repeated_targets_reje1",
    "native_lstat": {"st_file_attributes": 1024, "st_reparse_tag": LX_SYMLINK_REPARSE_TAG,
                      "is_symlink": False, "is_file": True},
    "original_inputs_unchanged": True,
    "partial_staging_retained": "validation/packaging_failed_unc_20261025",
    "target_source": "independent WSL find/readlink observation",
}


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def read_json(path: Path):
    return json.loads(path.read_bytes())


def json_bytes(value) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True,
                       allow_nan=False) + "\n").encode("utf-8")


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def git(repo: Path, *args: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(repo), *args], stderr=subprocess.STDOUT)


def exact_git_commit(repo: Path, commit: str) -> None:
    resolved = git(repo, "rev-parse", "--verify", f"{commit}^{{commit}}").decode().strip()
    need(resolved == commit, f"source commit did not resolve exactly: {commit}")


def source_snapshot(repo: Path, commit: str, relative: str) -> bytes:
    git(repo, "cat-file", "-e", f"{commit}:{relative}")
    return git(repo, "show", f"{commit}:{relative}")


def is_link(path: Path) -> bool:
    info = path.lstat()
    return path.is_symlink() or getattr(info, "st_reparse_tag", 0) == LX_SYMLINK_REPARSE_TAG


def link_target(path: Path) -> str:
    info = path.lstat()
    if getattr(info, "st_reparse_tag", 0) == LX_SYMLINK_REPARSE_TAG:
        raw = str(path.absolute())
        match = re.match(r"^\\\\(?:wsl\.localhost|wsl\$)\\([^\\]+)(.*)$", raw, re.IGNORECASE)
        need(match is not None, f"cannot map WSL UNC link path: {raw}")
        distro, suffix = match.groups()
        linux_path = "/" + suffix.replace("\\", "/").lstrip("/")
        target = subprocess.check_output(
            ["wsl.exe", "-d", distro, "--exec", "readlink", "--", linux_path],
            stderr=subprocess.STDOUT, text=True).rstrip("\r\n")
    else:
        target = os.readlink(path)
    need(isinstance(target, str) and target != "", f"empty/unreadable symlink target: {path}")
    return target


def regular_files(root: Path):
    """Yield regular files and link entries without traversing link targets."""
    for current, dirs, names in os.walk(root, followlinks=False):
        link_dirs, keep_dirs = [], []
        for name in dirs:
            path = Path(current) / name
            (link_dirs if is_link(path) else keep_dirs).append(path)
        dirs[:] = [path.name for path in sorted(keep_dirs)]
        yield from sorted(link_dirs)
        for name in sorted(names):
            path = Path(current) / name
            if is_link(path) or path.is_file():
                yield path


def reject_sensitive_name(path: Path) -> None:
    low = path.name.lower()
    need(not any(marker in low for marker in SENSITIVE_MARKERS),
         f"sensitive-looking file must be reviewed before packaging: {path}")


def reject_sensitive_value(path: Path) -> None:
    if path.suffix.lower() in TEXT_SUFFIXES:
        content = path.read_bytes()
        need(SENSITIVE_VALUE.search(content) is None,
             f"sensitive-looking value must be reviewed before packaging: {path}")


def add_file(zf: zipfile.ZipFile, member: str, path: Path, group: str):
    if is_link(path):
        target = link_target(path)
        data = target.encode("utf-8")
        info = zipfile.ZipInfo(member)
        info.create_system = 3
        info.external_attr = (stat.S_IFLNK | 0o777) << 16
        zf.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED)
        return {"member": member, "original_path": str(path.absolute()),
                "size": len(data), "sha256": sha_bytes(data), "group": group,
                "type": "symlink", "symlink_target": target}
    before = path.stat()
    digest = hashlib.sha256()
    count = 0
    with path.open("rb") as src, zf.open(member, "w", force_zip64=True) as dst:
        while True:
            block = src.read(1024 * 1024)
            if not block:
                break
            dst.write(block)
            digest.update(block)
            count += len(block)
    after = path.stat()
    need(before.st_size == after.st_size == count and before.st_mtime_ns == after.st_mtime_ns,
         f"input changed while archiving: {path}")
    return {"member": member, "original_path": str(path.resolve()), "type": "file",
            "size": count, "sha256": digest.hexdigest(), "group": group}


def add_blob(zf: zipfile.ZipFile, member: str, original: str, git_path: str, data: bytes):
    zf.writestr(member, data, compress_type=zipfile.ZIP_DEFLATED)
    return {"member": member, "original_path": original, "size": len(data),
            "sha256": sha_bytes(data), "group": "source_snapshot",
            "git_ref": EXPECTED_HEAD, "git_path": git_path}


def list_validation_files(root: Path, output: Path):
    files = []
    output_resolved = output.resolve()
    for path in regular_files(root):
        resolved = path.absolute() if is_link(path) else path.resolve()
        if resolved == output_resolved or output_resolved in resolved.parents:
            continue
        if path.suffix.lower() not in VALIDATION_SUFFIXES:
            continue
        if any(part in {".git", "__pycache__"} for part in path.relative_to(root).parts):
            continue
        reject_sensitive_name(path)
        if not is_link(path):
            reject_sensitive_value(path)
        files.append(path)
    return files


def inventory(root: Path):
    result = {}
    for path in regular_files(root):
        if is_link(path):
            target = link_target(path)
            data = target.encode("utf-8")
            result[path.relative_to(root).as_posix()] = {
                "type": "symlink", "target": target, "size": len(data), "sha256": sha_bytes(data)}
        else:
            result[path.relative_to(root).as_posix()] = {
                "size": path.stat().st_size, "sha256": sha_file(path)}
    return result


def check_historical_inputs(history: Path, interrupted: Path, final_binding: dict):
    historical_plan = read_json(history / "main" / "plan.json")
    historical_zero_plan = read_json(history / "synthetic-zero" / "plan.json")
    need(historical_plan.get("source_head") == HISTORICAL_HEAD
         and historical_zero_plan.get("source_head") == HISTORICAL_HEAD,
         "historical plans do not retain source44 identity")
    need(read_json(history / "main" / "comparison.json").get("status") == "PASSED"
         and read_json(history / "synthetic-zero" / "comparison.json").get("status") == "PASSED",
         "historical main/zero comparison artifacts are not PASSED")
    need(read_json(history / "core_readback.json").get("status") == "PASSED",
         "historical core_readback.json is not PASSED")
    lifecycle = read_json(history / "lifecycle" / "lifecycle.json")
    failures = [case for case in lifecycle.get("cases", []) if case.get("status") == "FAILED"]
    need(lifecycle.get("status") == "FAILED" and failures and lifecycle.get("failures"),
         "historical lifecycle failures were removed or rewritten")
    need({"late_solver", "late_certificate", "late_logging"} <= {c.get("mode") for c in failures},
         "historical late-phase lifecycle failures are not retained")
    hist_binding = read_json(history / "main" / "backend_binding.json")
    need(hist_binding.get("binding_id") != final_binding.get("binding_id"),
         "historical source44 and final source bindings are not distinct")
    for plan, profile in ((historical_plan, "main"), (historical_zero_plan, "synthetic-zero")):
        snapshots = history / profile / "frozen_adapter"
        for relative, expected in plan.get("source_closure", {}).items():
            path = snapshots / relative
            need(path.is_file() and sha_file(path) == expected,
                 f"historical source44 snapshot mismatch: {relative}")

    observation = read_json(history / "interruption_observation.json")
    original_inventory = observation.get("original_inventory")
    need(observation.get("status") == "INTERRUPTED_WITHOUT_EXIT_CODE"
         and observation.get("original_directory_resumed") is False
         and isinstance(original_inventory, dict) and original_inventory,
         "historical interruption observation is incomplete")
    need(inventory(interrupted) == original_inventory,
         "original interrupted namespace inventory changed")
    old_plan = read_json(interrupted / "main" / "plan.json")
    old_report = read_json(interrupted / "main" / "comparison.json")
    need(old_plan.get("source_head") == HISTORICAL_HEAD
         and old_report.get("status") == "RUNNING" and len(old_report.get("cells", [])) == 3,
         "original interrupted source44 state changed")
    pending = interrupted / "main" / "B-D-BRANCH-S2_FULL"
    need((pending / "dispatch_reference.json").is_file()
         and not (pending / "reference" / "result.json").exists(),
         "original B/FULL reference dispatch gained a verdict")
    return {"history_binding_id": hist_binding["binding_id"],
            "historical_lifecycle_status": "FAILED", "retained_lifecycle_failures": len(failures),
            "interrupted_inventory_files": len(original_inventory),
            "incomplete_dispatch": "B-D-BRANCH-S2/FULL/reference"}


def validate_inputs(repo: Path, namespace: Path, history: Path,
                    interrupted: Path, validation: Path, output: Path,
                    source_commit: str):
    for label, path in (("repo", repo), ("namespace", namespace), ("history", history),
                        ("interrupted", interrupted), ("validation", validation)):
        need(path.is_dir(), f"{label} directory is unavailable: {path}")
    need(not output.exists(), f"evidence output already exists; refusing to overwrite: {output}")
    need(source_commit == EXPECTED_HEAD, "source commit argument differs from reviewed final commit")
    exact_git_commit(repo, source_commit)
    proof = namespace / "scientific_readback.json"
    need(proof.is_file(), "final scientific_readback.json is missing")
    proof_value = read_json(proof)
    need(proof_value.get("status") == "PASSED" and proof_value.get("head") == source_commit,
         "final root scientific readback is not PASS for the requested source commit")
    need(proof_value.get("main_cells") == 13 and proof_value.get("main_qualified_deliveries") == 26
         and proof_value.get("main_workers") == {"fresh": 26, "carried": 0}
         and proof_value.get("zero_cells") == 3 and proof_value.get("zero_qualified_deliveries") == 6,
         "final scientific readback does not describe the fresh 26+6 qualification")
    plan = read_json(namespace / "main" / "plan.json")
    binding = read_json(namespace / "main" / "backend_binding.json")
    need(plan.get("source_head") == source_commit and plan.get("expected_method_workers") == 26,
         "final main plan source or worker count mismatch")
    need(plan.get("formal_campaign") is False, "final main plan is not qualification-only")
    history_record = check_historical_inputs(history, interrupted, binding)
    historical = proof_value.get("historical", {})
    need(historical.get("lifecycle_status") == "FAILED"
         and historical.get("old_binding_id") is not None,
         "proof does not preserve the historical failed lifecycle as a separate result")
    need(historical.get("interruption", {}).get("incomplete_dispatch") == "B-D-BRANCH-S2/FULL/reference"
         and historical.get("interruption", {}).get("verdict") == "ABSENT",
         "proof does not retain the original incomplete B/FULL dispatch")
    need(historical.get("old_source", {}).get("head") == HISTORICAL_HEAD
         and historical.get("old_zero_source", {}).get("head") == HISTORICAL_HEAD,
         "final readback does not preserve the source44 snapshots")
    return proof, proof_value, plan, binding, history_record


def build_index(proof_value, plan, binding, source_commit, history, interrupted):
    historical = proof_value["historical"]
    return {
        "schema": "cmr-unified-v12-evidence-index-v1",
        "status": "AWAITING_ROOT_ARCHIVE_READBACK",
        "aggregate_status": "NOT_CLAIMED",
        "source_commit": source_commit,
        "final_qualification": {
            "status": proof_value["status"], "source_head": proof_value["head"],
            "main_cells": proof_value["main_cells"],
            "main_qualified_deliveries": proof_value["main_qualified_deliveries"],
            "fresh_main_workers": proof_value["main_workers"]["fresh"],
            "zero_cells": proof_value["zero_cells"],
            "zero_qualified_deliveries": proof_value["zero_qualified_deliveries"],
            "source_closure_files": proof_value["source_closure"]["main"]["closure_files"],
            "version_binding_id": plan["version_binding_id"],
            "version_binding_sha256": plan["version_binding_sha256"],
            "backend_binding_id": binding["binding_id"],
            "backends": binding["backends"],
        },
        "historical_qualification": {
            "namespace": str(history.resolve()), "source_head": HISTORICAL_HEAD,
            "main_cells": historical["main_cells"], "main_workers": historical["main_workers"],
            "zero_cells": historical["zero_cells"], "zero_workers": historical["zero_workers"],
            "comparison_core_readback": historical["core_readback"],
            "lifecycle_status": historical["lifecycle_status"],
            "retained_failed_lifecycle_cases": historical["retained_lifecycle_failures"],
            "failed_lifecycle_modes": historical["failed_modes"],
            "comparison_status": "PASSED",
            "zero_comparison_status": "PASSED",
            "source_snapshots": {"main": historical["old_source"],
                                 "zero": historical["old_zero_source"]},
        },
        "interrupted_original": {
            "namespace": str(interrupted.resolve()), "status": "INTERRUPTED_WITHOUT_EXIT_CODE",
            "incomplete_dispatch": "B-D-BRANCH-S2/FULL/reference", "verdict": "ABSENT",
        },
        "archive_readback": "PENDING",
    }


def package(args):
    repo, namespace, history = args.repo.resolve(), args.namespace.resolve(), args.history.resolve()
    interrupted, validation = args.interrupted.resolve(), args.validation.resolve()
    output = args.output.resolve()
    need(output.is_relative_to(repo), 'evidence output must stay within the named repository')
    proof, proof_value, plan, binding, history_record = validate_inputs(
        repo, namespace, history, interrupted, validation, output, args.source_commit)
    output.parent.mkdir(parents=True, exist_ok=True)
    temp_root = Path(tempfile.mkdtemp(prefix=".v12-evidence-", dir=output.parent))
    try:
        proof_copy = temp_root / "root_scientific_readback.json"
        shutil.copyfile(proof, proof_copy)
        need(sha_file(proof_copy) == sha_file(proof), "root scientific proof copy hash mismatch")
        members = []
        seen = set()
        zip_path = temp_root / "v12_evidence_20261025.zip"
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=6, allowZip64=True) as zf:
            roots = (("namespace", namespace), ("history_namespace", history),
                     ("interrupted_namespace", interrupted))
            for prefix, root in roots:
                for path in regular_files(root):
                    reject_sensitive_name(path)
                    if not is_link(path):
                        reject_sensitive_value(path)
                    member = f"{prefix}/{path.relative_to(root).as_posix()}"
                    need(member not in seen, f"duplicate archive member: {member}")
                    members.append(add_file(zf, member, path, prefix))
                    seen.add(member)
            metadata_member = "packaging_failure_observation.json"
            metadata_bytes = json_bytes(PACKAGING_FAILURE_OBSERVATION)
            zf.writestr(metadata_member, metadata_bytes, compress_type=zipfile.ZIP_DEFLATED)
            members.append({"member": metadata_member,
                            "original_path": "recorded independent packaging observation",
                            "size": len(metadata_bytes), "sha256": sha_bytes(metadata_bytes),
                            "group": "packaging_observation", "type": "metadata"})
            seen.add(metadata_member)
            for path in list_validation_files(validation, output):
                member = f"validation/{path.relative_to(validation).as_posix()}"
                need(member not in seen, f"duplicate archive member: {member}")
                members.append(add_file(zf, member, path, "validation"))
                seen.add(member)
            for relative in SOURCE_FILES:
                blob = source_snapshot(repo, args.source_commit, relative)
                member = "source_snapshots/" + relative
                need(member not in seen, f"duplicate archive member: {member}")
                members.append(add_blob(zf, member,
                    f"git:{args.source_commit}:{relative}", relative, blob))
                seen.add(member)
            proof_member = "root_scientific_readback.json"
            proof_bytes = proof.read_bytes()
            need(proof_member not in seen, f"duplicate archive member: {proof_member}")
            zf.writestr(proof_member, proof_bytes, compress_type=zipfile.ZIP_DEFLATED)
            members.append({"member": proof_member, "original_path": str(proof.resolve()),
                            "size": len(proof_bytes), "sha256": sha_bytes(proof_bytes),
                            "group": "root_proof_copy"})
            seen.add(proof_member)
        archive_manifest = {
            "schema": "cmr-unified-v12-archive-manifest-v1",
            "source_commit": args.source_commit,
            "source_snapshot_count": len(SOURCE_FILES),
            "zip": zip_path.name,
            "member_count": len(members),
            "members": members,
        }
        archive_manifest_path = temp_root / "archive_manifest.json"
        archive_manifest_path.write_bytes(json_bytes(archive_manifest))
        artifact_manifest = {
            "schema": "cmr-unified-v12-artifact-manifest-v1",
            "source_commit": args.source_commit,
            "artifacts": [
                {"path": zip_path.name, "size": zip_path.stat().st_size, "sha256": sha_file(zip_path)},
                {"path": archive_manifest_path.name, "size": archive_manifest_path.stat().st_size,
                 "sha256": sha_file(archive_manifest_path)},
                {"path": proof_copy.name, "size": proof_copy.stat().st_size,
                 "sha256": sha_file(proof_copy)},
            ],
            "self_hash": "OMITTED_TO_AVOID_CYCLE",
        }
        artifact_manifest_path = temp_root / "artifact_manifest.json"
        artifact_manifest_path.write_bytes(json_bytes(artifact_manifest))
        index = build_index(proof_value, plan, binding, args.source_commit, history, interrupted)
        index["historical_qualification"].update(history_record)
        index["source_snapshot_count"] = len(SOURCE_FILES)
        index["archive"] = zip_path.name
        index["archive_manifest"] = archive_manifest_path.name
        index["artifact_manifest"] = artifact_manifest_path.name
        index["artifact_manifest_sha256"] = sha_file(artifact_manifest_path)
        (temp_root / "index.json").write_bytes(json_bytes(index))
        need(temp_root.resolve().parent == output.parent.resolve()
             and output.resolve().parent == output.parent.resolve(),
             'resolved staging/output directories escaped the intended evidence parent')
        os.replace(temp_root, output)
    except Exception:
        # Retain partial packaging artifacts and the checked staging path.
        (temp_root / 'packaging_incomplete.txt').write_text(
            'Packaging failed; original inputs are unchanged. Staging retained.\n', encoding='utf-8')
        raise
    return {
        "status": "AWAITING_ROOT_ARCHIVE_READBACK",
        "output": str(output),
        "zip": str(output / "v12_evidence_20261025.zip"),
        "member_count": len(members),
        "zip_sha256": sha_file(output / "v12_evidence_20261025.zip"),
        "artifact_manifest_sha256": sha_file(output / "artifact_manifest.json"),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--namespace", type=Path, required=True)
    parser.add_argument("--history", type=Path, required=True)
    parser.add_argument("--interrupted", type=Path, required=True)
    parser.add_argument("--validation", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--source-commit", required=True)
    args = parser.parse_args()
    print(json.dumps(package(args), sort_keys=True))


if __name__ == "__main__":
    main()
