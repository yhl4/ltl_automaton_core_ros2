"""Unified V12 backend qualification adapters."""
