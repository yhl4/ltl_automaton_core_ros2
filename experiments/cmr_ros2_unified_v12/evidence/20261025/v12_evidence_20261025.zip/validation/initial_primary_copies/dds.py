"""Explicit V12 DDS adapter over the qualified ROS2 CMR smoke transport.

The request is bound to one V12 descriptor and one plan cell. DDS remains a
transport qualification; it does not authorize the formal campaign.
"""
from __future__ import annotations

import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
from types import SimpleNamespace
from typing import Any, Mapping

from experiments.cmr_ros2_integration import dds_smoke as transport
from experiments.cmr_ros2_backend.dds import _wait_processes


HERE = Path(__file__).resolve().parent
DOMAIN_ID = 227
SERVER_SECONDS = 205.0
TRANSPORT_SECONDS = 210.0
SCHEMA = transport.SCHEMA
BACKEND = "ros2-v12"


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2, default=str) + "\n",
                    encoding="utf-8")


def _fixed_cells(plan: Mapping[str, Any]) -> dict[tuple[str, str], dict[str, Any]]:
    cells = plan.get("cells")
    if not isinstance(cells, list) or not cells:
        raise ValueError("V12 DDS plan has no cells")
    observed = [(cell.get("instance_id"), cell.get("method")) for cell in cells]
    if len(set(observed)) != len(observed):
        raise ValueError("V12 DDS plan contains duplicate cells")
    if any(method not in {"FULL", "AP-D", "DEP-D"} for _, method in observed):
        raise ValueError("V12 DDS plan contains an unsupported method")
    if (plan.get("formal_campaign") is not False
            or plan.get("planner_budget_seconds") != 180
            or plan.get("outer_watchdog_seconds") != 195):
        raise ValueError("V12 DDS plan budget or campaign contract changed")
    return {(cell["instance_id"], cell["method"]): cell for cell in cells}


def _case_map(plan: Mapping[str, Any]) -> dict[tuple[str, str], dict[str, Any]]:
    cases = plan.get("dds_cases")
    if not isinstance(cases, list) or not cases:
        raise ValueError("V12 plan must bind explicit DDS cases")
    out = {}
    for case in cases:
        key = (case.get("instance_id"), case.get("method"))
        if key in out or case.get("expected_terminal") not in {
                "OPTIMALITY_CERTIFIED", "INFEASIBLE_CERTIFIED", "TIMEOUT",
                "INFRASTRUCTURE_FAILURE", "ERROR"}:
            raise ValueError("invalid or duplicate V12 DDS case")
        out[key] = dict(case)
    return out


class V12Server(transport._Server):
    """Serve one exact V12 request and its certified execution snapshot."""

    def __init__(self, request: dict[str, Any], binding: str, kernel_root: str,
                 work_dir: Path, plan_path: str | Path):
        super().__init__(request, binding, kernel_root, work_dir)
        self.binding = binding
        self.kernel_root = kernel_root
        self.plan_path = Path(plan_path).resolve()
        self.identity = f"cmr-ros2-v12-{request['request_id']}"

    def _request(self, message) -> None:
        if self.done:
            return
        request = json.loads(message.data)
        if request != self.request:
            raise ValueError("DDS request differs from the bound V12 envelope")
        self.done = True
        try:
            runner = importlib.import_module("experiments.cmr_ros2_unified_v12.runner")
            plan = runner.load_plan(self.plan_path)
            cell = _fixed_cells(plan)[(request["instance_id"], request["method"])]
            entry = runner.AttemptEntry(self.plan_path)
            expected = dict(runner.request_for(plan, entry, cell, BACKEND),
                            request_id=request["request_id"])
            if request != expected:
                raise ValueError("V12 DDS request identity mismatch")
            entry.validate(plan, request, BACKEND)
            args = SimpleNamespace(binding=self.binding, kernel_root=self.kernel_root,
                                   output=self.plan_path.parent)
            attempt = self.work_dir / "cmr_attempt"
            value = runner.candidate_isolated(args, plan, cell, attempt,
                                              backend_name=BACKEND)
            row, descriptor = value["row"], value["backend_binding"]
            for key in ("backend", "backend_id", "backend_sha256",
                        "version_binding_id", "version_binding_sha256"):
                if descriptor.get(key) != request.get(key):
                    raise ValueError(f"V12 result identity differs for {key}")
            self.result = dict(row, schema=SCHEMA, population=request["population"],
                request_id=request["request_id"], instance_id=request["instance_id"],
                method=request["method"], backend=BACKEND, variant="real",
                worker_pid=value["worker_pid"], worker_exitcode=value["worker_exitcode"],
                worker_alive_after_cleanup=value["worker_alive_after_cleanup"],
                backend_binding=descriptor)
            if value.get("transport") is not None:
                self.result.update(value["transport"])
            _write(attempt / "dds_result.json", self.result)
        except Exception as error:
            details = traceback.format_exc()
            descriptor = {key: request.get(key) for key in (
                "backend", "backend_id", "backend_sha256",
                "version_binding_id", "version_binding_sha256")}
            self.result = dict(schema=SCHEMA, population=request["population"],
                request_id=request["request_id"], instance_id=request["instance_id"],
                method=request["method"], backend=BACKEND, variant="real",
                terminal_status="ERROR", objective=None, concrete_lasso=None,
                error=repr(error), backend_binding=descriptor, **descriptor,
                certificate_valid_for_terminal=False,
                certificate_verifier_status="NOT_AVAILABLE", right_censored=False)
            (self.work_dir / "server_traceback.txt").write_text(details, encoding="utf-8")
            sys.stderr.write(details)
        outgoing = json.dumps(self.result, sort_keys=True, separators=(",", ":"))
        self.result_pub.publish(self.String(data=outgoing))
        if self.result.get("terminal_status") != "OPTIMALITY_CERTIFIED":
            self._grace_deadline = time.monotonic() + 0.5
            return
        self.snapshot, self.transitions, self.state_ids = transport._snapshot_messages(
            self.result, self.identity)
        self._publish_observation()


def _child(role: str, request_path: Path, work_dir: Path, seconds: float,
           binding: str, kernel_root: str, plan_path: str) -> int:
    request = json.loads(request_path.read_text(encoding="utf-8"))
    import rclpy
    rclpy.init()
    try:
        worker = (V12Server(request, binding, kernel_root, work_dir, plan_path)
                  if role == "server" else transport._Driver(request, work_dir))
        worker.run(seconds)
        return 0
    except Exception:
        details = traceback.format_exc()
        (work_dir / f"{role}_error.txt").write_text(details, encoding="utf-8")
        sys.stderr.write(details)
        return 1
    finally:
        rclpy.shutdown()


def _run_case(request: dict[str, Any], args, case_dir: Path,
              descriptor: dict[str, Any]) -> dict[str, Any]:
    case_dir.mkdir(parents=True, exist_ok=False)
    request_path = case_dir / "request.json"
    _write(request_path, request)
    env = dict(os.environ, ROS_DOMAIN_ID=str(DOMAIN_ID), ROS_LOCALHOST_ONLY="1",
               PYTHONDONTWRITEBYTECODE="1")
    processes, streams = {}, []
    error = None
    try:
        for role in ("server", "driver"):
            stdout = (case_dir / f"{role}.stdout").open("w", encoding="utf-8")
            stderr = (case_dir / f"{role}.stderr").open("w", encoding="utf-8")
            streams.extend((stdout, stderr))
            command = [sys.executable, "-B", str(HERE / "dds.py"), "--role", role,
                       "--request", str(request_path), "--work-dir", str(case_dir),
                       "--seconds", str(SERVER_SECONDS), "--binding", str(args.binding),
                       "--kernel-root", str(args.kernel_root), "--plan", str(args.plan)]
            processes[role] = subprocess.Popen(command, env=env, stdout=stdout, stderr=stderr)
        _wait_processes(processes, time.monotonic() + TRANSPORT_SECONDS)
    except Exception as exc:
        error = exc
    finally:
        for process in processes.values():
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=1.0)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=1.0)
        for stream in streams:
            stream.close()
        for role, process in processes.items():
            (case_dir / f"{role}.rc").write_text(str(process.returncode) + "\n")
    if error is not None:
        raise error
    attempt = case_dir / "cmr_attempt"
    return {"schema": "cmr-unified-v12-dds-case-v1", "status": "RUNNING",
        "domain_id": DOMAIN_ID, "ros_localhost_only": True,
        "request_topic": transport.REQUEST_TOPIC, "result_topic": transport.RESULT_TOPIC,
        "observation_topic": transport.OBSERVATION_TOPIC,
        "snapshot_service": transport.SNAPSHOT_SERVICE, "ts_topic": transport.TS_TOPIC,
        "command_topic": transport.COMMAND_TOPIC, "request": request,
        "descriptor": descriptor, "server_pid": processes["server"].pid,
        "driver_pid": processes["driver"].pid,
        "server_rc": processes["server"].returncode,
        "driver_rc": processes["driver"].returncode,
        "server": json.loads((case_dir / "server_events.json").read_text())
            if (case_dir / "server_events.json").exists() else {},
        "driver": json.loads((case_dir / "driver_events.json").read_text())
            if (case_dir / "driver_events.json").exists() else {},
        "certificate_replay": json.loads((attempt / "certificate_replay.json").read_bytes())
            if (attempt / "certificate_replay.json").exists() else None,
        "module": str(HERE / "dds.py")}


def run_dds(args, plan: dict[str, Any], output: Path) -> dict[str, Any]:
    runner = importlib.import_module("experiments.cmr_ros2_unified_v12.runner")
    plan = runner.load_plan(args.plan)
    cells, cases = _fixed_cells(plan), _case_map(plan)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    report = {"schema": "cmr-unified-v12-dds-report-v1", "status": "RUNNING",
              "domain_id": DOMAIN_ID, "transport_seconds": TRANSPORT_SECONDS,
              "cases": [], "targets": [list(key) for key in cases]}
    descriptor = None
    for key, case in cases.items():
        request_id = f"cmr-v12-{key[0]}-{key[1]}".replace("/", "-")
        artifact = {"schema": "cmr-unified-v12-dds-case-v1", "status": "FAILED",
                    "request": None}
        case_dir = output / request_id
        try:
            cell = cells[key]
            entry = runner.AttemptEntry(args.plan)
            descriptor = entry.describe(args.version_binding, BACKEND)
            request = runner.request_for(plan, entry, cell, BACKEND)
            request.update(request_id=request_id)
            artifact["request"] = request
            entry.validate(plan, request, BACKEND)
            artifact = _run_case(request, args, case_dir, descriptor)
            result = artifact.get("driver", {}).get("result", {})
            if artifact["server_rc"] != 0 or artifact["driver_rc"] != 0:
                raise ValueError("DDS child process failed")
            if result.get("backend_binding") != descriptor:
                raise ValueError("V12 DDS result descriptor mismatch")
            if result.get("terminal_status") != case["expected_terminal"]:
                raise ValueError("V12 DDS terminal status mismatch")
            if case["expected_terminal"] == "OPTIMALITY_CERTIFIED":
                attempt = case_dir / "cmr_attempt"
                value = json.loads((attempt / "result.json").read_bytes())
                replay = runner.replay(plan, args.binding, args.kernel_root, value, attempt)
                _write(attempt / "certificate_replay.json", replay)
                artifact["certificate_replay"] = replay
                if replay.get("status") != "PASS":
                    raise ValueError("V12 independent certificate replay failed")
            artifact["status"] = "PASSED"
        except Exception as exc:
            artifact["status"] = "FAILED"
            artifact["error"] = repr(exc)
            artifact["traceback"] = traceback.format_exc()
        case_dir.mkdir(parents=True, exist_ok=True)
        _write(case_dir / "dds_artifact.json", artifact)
        report["cases"].append(artifact)
    report["descriptor"] = descriptor
    report["status"] = "PASSED" if all(x.get("status") == "PASSED" for x in report["cases"]) else "FAILED"
    _write(output / "dds_report.json", report)
    return report


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--role", choices=("server", "driver"), required=True)
    parser.add_argument("--request", required=True, type=Path)
    parser.add_argument("--work-dir", required=True, type=Path)
    parser.add_argument("--seconds", required=True, type=float)
    parser.add_argument("--binding", required=True)
    parser.add_argument("--kernel-root", required=True)
    parser.add_argument("--plan", required=True)
    args = parser.parse_args(argv)
    return _child(args.role, args.request, args.work_dir, args.seconds,
                  args.binding, args.kernel_root, args.plan)


if __name__ == "__main__":
    raise SystemExit(main())
