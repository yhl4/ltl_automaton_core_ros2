#!/usr/bin/env python3
"""Offline AST and request-envelope checks; never imports the worker stack."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
from typing import Any, Mapping


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def extract(tree, names):
    namespace = {'Mapping': Mapping, 'Any': Any}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in names:
            exec(compile(ast.Module(body=[node], type_ignores=[]), '<ast-check>', 'exec'), namespace)
    return namespace


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    package = args.repo / 'experiments/cmr_ros2_unified_v12'
    files = ('backend.py', 'runner.py', 'fixtures.py', 'offline_chain.py',
             'dds.py', 'lifecycle.py', 'campaign.py')
    trees = {name: ast.parse((package / name).read_text(encoding='utf-8'),
                             filename=name) for name in files}
    dds = extract(trees['dds.py'], {'_case_specs', '_request_envelope'})
    for method in ('FULL', 'AP-D', 'DEP-D'):
        cell = {'instance_id': 'C3-T4', 'method': method,
                'planner_budget_seconds': 180, 'outer_watchdog_seconds': 195}
        envelope = dds['_request_envelope'](
            cell, {'backend': 'ros2-v12'}, 'qualification', 'scope',
            'execution', 'request', instance_sha256='a' * 64)
        assert envelope['method'] == method
        assert envelope['backend'] == 'ros2-v12'
        assert 'harness_mode' not in envelope and 'fault_mode' not in envelope
    cases = dds['_case_specs']({'profile': 'main'})
    assert len(cases) == 7
    assert len({(c['instance_id'], c['method'], c['fault_mode']) for c in cases}) == 7
    assert [c['expected_terminal'] for c in cases[-3:]] == [
        'TIMEOUT', 'INFRASTRUCTURE_FAILURE', 'ERROR']
    lifecycle_text = (package / 'lifecycle.py').read_text(encoding='utf-8')
    lifecycle_tree = trees['lifecycle.py']
    hooks = next(node for node in lifecycle_tree.body
                 if isinstance(node, ast.FunctionDef) and node.name == '_parent_hooks')
    hooks_dump = ast.dump(hooks)
    assert 'checked_delivery' in hooks_dump and '_clone_function' in hooks_dump
    assert 'watchdog_cooperative' in lifecycle_text
    campaign_tree = trees['campaign.py']
    qualify_fault = next(node for node in campaign_tree.body
                         if isinstance(node, ast.FunctionDef) and node.name == 'qualify_fault')
    assert any(isinstance(node, ast.Try) and node.finalbody
               for node in ast.walk(qualify_fault))
    result = {
        'schema': 'cmr-unified-v12-static-qualification-v1',
        'status': 'PASSED',
        'source_sha256': {name: sha(package / name) for name in files},
        'checks': ['AST parse for seven V12 source files',
                   'method-independent plan-envelope smoke FULL/AP-D/DEP-D',
                   'fixed DDS case IDs and failure terminals',
                   'lifecycle checked-delivery clock hook and cooperative watchdog syntax',
                   'campaign fault-hook restoration in finally'],
        'actual_workers': 0, 'solver_calls': 0, 'dds_calls': 0,
        'formal_verifier_calls': 0,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n',
                           encoding='utf-8')
    print(json.dumps({'status': result['status'], 'output': str(args.output)}))


if __name__ == '__main__':
    main()
