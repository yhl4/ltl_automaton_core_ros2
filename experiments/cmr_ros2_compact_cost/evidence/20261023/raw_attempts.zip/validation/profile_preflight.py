"""One original preflight call; no solver, worker or certificate execution."""
import cProfile
import hashlib
import json
from pathlib import Path
import pstats
import subprocess
import sys
import time

source = Path('/tmp/cmr_v11_source_e5ff912_20261023')
kernel = Path('/mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel')
sys.path[:0] = [str(source), str(kernel)]
from experiments.cmr_ros2_exact_cost_reuse import runner

assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == 'e5ff91294b373a1f33e7ae9458641e4a2200ab56'
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True).strip()
out = Path('/mnt/c/Users/Yuhling/.codex/worktrees/v7-audit-dds-regression/preflight_profile_20261023')
target = out / 'profile_preflight.json'
if target.exists():
    raise ValueError('retain the existing profile; do not rerun it')
plan = runner.load_plan(Path('/tmp/cmr_v11_exact_cost_e5ff912_20261023/plan.json'))
formal, bound, manifest, records = runner.original.authority(plan, runner.adapter._native_path(plan['authority_receipt']), kernel)
profile = cProfile.Profile()
started = time.perf_counter_ns()
result = profile.runcall(formal.preflight)
elapsed = time.perf_counter_ns() - started
assert result['status'] == 'PASS' and elapsed < 180_000_000_000
stats = pstats.Stats(profile)
rows = [dict(file=k[0], line=k[1], name=k[2], primitive_calls=v[0], calls=v[1], self_seconds=v[2], cumulative_seconds=v[3]) for k, v in stats.stats.items()]
value = dict(schema='cmr-preflight-profile-v1', status='PASSED', source_commit=plan['source_head'], source_closure=plan['source_closure'], authority_preflight=result, elapsed_ns=elapsed, scope='one original loaded preflight call; tracemalloc off as in run_one input phase; nested profile times overlap', solver_calls=0, real_workers=0, verifier_calls=0, dds_requests=0, provider_calls=0, formal_campaign=False, functions=sorted(rows, key=lambda r:r['cumulative_seconds'], reverse=True))
target.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
profile.dump_stats(str(out / 'profile_preflight.pstats'))
print(json.dumps(dict(status=value['status'], elapsed_ns=elapsed, functions=value['functions'][:18]), sort_keys=True))
