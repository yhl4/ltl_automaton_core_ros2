"""Package completed V12 evidence without executing a planner or verifier."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

repo = Path(r'C:\Users\Yuhling\.codex\worktrees\v7-audit-dds-regression\ltl_automaton_core-ros2')
helpers = Path(__file__).resolve().parent
runtime = Path(r'\\wsl.localhost\Ubuntu-22.04-D\tmp\cmr_v12_compact_cost_3cd0d16_20261023_r2')
interrupted = Path(r'\\wsl.localhost\Ubuntu-22.04-D\tmp\cmr_v12_compact_cost_3cd0d16_20261023')
commit = '3cd0d168a8a93f441cd195e6fa9743cb6d213218'
destination = repo / 'experiments/cmr_ros2_compact_cost/evidence/20261023'

def read(path):
    return json.loads(path.read_bytes())

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    path.write_bytes((json.dumps(value, indent=2, sort_keys=True)+'\n').encode())

result = read(helpers/'readback_final.json')
assert result['status'] == 'PASSED' and result['source_head'] == commit
assert (helpers/'recovery_run.rc').read_text().strip() == '0'
assert read(runtime/'comparison.json')['status'] == 'PASSED'
destination.mkdir(parents=True, exist_ok=False)
members = []
with zipfile.ZipFile(destination/'raw_attempts.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for prefix, root, kind in (('namespace', runtime, 'runtime_namespace'), ('interrupted_namespace', interrupted, 'interrupted_runtime_namespace'), ('validation', helpers, 'development_artifact')):
        for path in sorted(p for p in root.rglob('*') if p.is_file()):
            name = prefix+'/'+path.relative_to(root).as_posix()
            data = path.read_bytes()
            archive.writestr(name, data)
            members.append(dict(name=name, kind=kind, original_path=str(path), size=len(data), sha256=digest(data)))
    for name in ('backend.py', 'search.py', 'fixtures.py', 'runner.py'):
        source = 'experiments/cmr_ros2_compact_cost/'+name
        data = subprocess.check_output(['git', '-C', str(repo), 'show', commit+':'+source])
        member = 'source_snapshots/'+name
        archive.writestr(member, data)
        members.append(dict(name=member, kind='source_snapshot', original_path='git:'+commit+':'+source, size=len(data), sha256=digest(data)))
members.sort(key=lambda row:row['name'])
write(destination/'archive_manifest.json', dict(schema='cmr-v12-compact-cost-archive-manifest-v1', source_commit=commit, member_count=len(members), members=members))
def artifact(name):
    data = (destination/name).read_bytes()
    return dict(path=name, size=len(data), sha256=digest(data))
write(destination/'artifact_manifest.json', dict(schema='cmr-v12-compact-cost-artifact-manifest-v1', excludes=['index.json', 'artifact_manifest.json'], files=[artifact(n) for n in ('raw_attempts.zip', 'archive_manifest.json')]))
write(destination/'index.json', dict(schema='cmr-v12-compact-cost-evidence-index-v1', status='AWAITING_ROOT_ARCHIVE_READBACK', source_commit=commit, source_branch='codex/v12-compact-cost', baseline_commit='8cfb6bdf28496b3bc242402f973a17d258781543', binding_id=result['version_binding_id'], binding_sha256=result['version_binding_sha256'], backend_sha256=result['backend_sha256'], source_files=result['source_files'], frozen_inputs=result['frozen_inputs'], workers=result['actual_workers'], recorded_rounds=result['total_rounds'], internal_certificate_verifications=result['observed_internal_certificate_verifications'], additional_certificate_replays=result['additional_persisted_replays_pass'], summary=result['summary'], archive=artifact('raw_attempts.zip'), archive_manifest=artifact('archive_manifest.json'), artifact_manifest=artifact('artifact_manifest.json'), archive_members=len(members), previous_v11_archive_sha256='9cad781b5d3f9c81076786ae053256a8a2060324c197816f05c20fdcb003b5a2', limits=dict(synthetic_fixture_solver_calls='unknown', preflight_profile_calls=1, preflight_profile_solver_calls=0, failed_development_source_versions='not retained', preflight='unchanged; all fresh hash and path checks retained', formal_campaign=False, dds_requests=0, provider_calls=0, default_changed=False)))
print(json.dumps(dict(status='PACKAGED', members=len(members), archive=artifact('raw_attempts.zip')), sort_keys=True))
