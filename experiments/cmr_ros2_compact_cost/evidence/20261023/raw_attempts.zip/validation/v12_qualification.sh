#!/usr/bin/env bash
set -o pipefail
src=/mnt/d/Robotics/Robotics4LLM/ltl_automaton_core-ros2
dst=/tmp/cmr_v12_source_3cd0d16_20261023
out=/tmp/cmr_v12_compact_cost_3cd0d16_20261023
kernel=/mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel
receipt=/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json
art=/mnt/c/Users/Yuhling/.codex/worktrees/v7-audit-dds-regression/preflight_profile_20261023
expected=3cd0d168a8a93f441cd195e6fa9743cb6d213218

setup_ros() {
  source /opt/ros/humble/setup.bash || return $?
  source /tmp/ltl_ros2_combo_bd75495/install/setup.bash || return $?
  export PYTHONDONTWRITEBYTECODE=1
  export PYTHONPATH="$dst/ltl_automaton_execution:$dst/ltl_automaton_planner:$dst/ltl_automaton_planner_core:$dst:$kernel${PYTHONPATH:+:$PYTHONPATH}"
}

case "${1:-}" in
  clone)
    if [[ -e "$dst" || -e "$out" ]]; then echo "clone/output path already exists" >&2; exit 20; fi
    git clone --branch codex/v12-compact-cost --single-branch "$src" "$dst" > "$art/v12_clone.log" 2>&1
    rc=$?; printf '%s\n' "$rc" > "$art/v12_clone.rc"
    if (( rc != 0 )); then exit "$rc"; fi
    actual=$(git -C "$dst" rev-parse HEAD) || exit 21
    [[ "$actual" == "$expected" ]] || { echo "wrong clone HEAD: $actual" >&2; exit 22; }
    [[ -z "$(git -C "$dst" status --porcelain)" ]] || { echo "fresh clone is dirty" >&2; exit 23; }
    [[ ! -e "$out" ]] || { echo "qualification output path already exists" >&2; exit 24; }
    printf 'HEAD=%s\nCLEAN=yes\nOUTPUT_ABSENT=yes\n' "$actual"
    ;;
  guard)
    [[ "$(git -C "$dst" rev-parse HEAD)" == "$expected" ]] || exit 30
    set +e
    cd "$dst" && setup_ros && python3 - <<'PY' > "$art/v12_importguard.log" 2>&1
import hashlib
import importlib
import json
from pathlib import Path

root = Path('/tmp/cmr_v12_source_3cd0d16_20261023').resolve()
kernel = Path('/mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel').resolve()
dp = importlib.import_module('ltl_automaton_planner_core.ltl_tools.discrete_plan')
dp_path = Path(dp.__file__).resolve()
assert dp_path.is_relative_to(root), dp_path
actual_dp_sha = hashlib.sha256(dp_path.read_bytes()).hexdigest()
assert actual_dp_sha == '556b6925a61ce408a0b42d56da45138fcdf3c7c7655e7850eb17b551996df31b', actual_dp_sha
v11 = importlib.import_module('experiments.cmr_ros2_exact_cost_reuse.backend')
actual_v11 = v11.identity()
assert actual_v11 == '35838cf764a85cd04e3376825d1f807bbb458bb2c39418046bd2f2624abb9cd4', actual_v11
runner = importlib.import_module('experiments.cmr_ros2_compact_cost.runner')
closure = runner.source_closure()
assert len(closure) == 77, len(closure)
assert kernel.is_dir(), kernel
print(json.dumps({'importguard': 'PASS', 'discrete_plan': str(dp_path),
                  'discrete_plan_sha256': actual_dp_sha,
                  'pinned_v11_identity': actual_v11,
                  'source_closure_count': len(closure)}, sort_keys=True))
PY
    rc=$?; printf '%s\n' "$rc" > "$art/v12_importguard.rc"
    exit "$rc"
    ;;
  prepare)
    [[ -f "$art/v12_importguard.rc" && "$(cat "$art/v12_importguard.rc")" == 0 ]] || { echo "importguard did not pass" >&2; exit 31; }
    [[ ! -e "$out" ]] || { echo "qualification output path already exists" >&2; exit 32; }
    set +e
    cd "$dst" && setup_ros && python3 "$dst/experiments/cmr_ros2_compact_cost/runner.py" --prepare --binding "$receipt" --kernel-root "$kernel" --output "$out" > "$art/v12_prepare.log" 2>&1
    rc=$?; printf '%s\n' "$rc" > "$art/v12_prepare.rc"
    exit "$rc"
    ;;
  run)
    [[ -f "$art/v12_prepare.rc" && "$(cat "$art/v12_prepare.rc")" == 0 ]] || { echo "prepare did not pass; runner dispatch prohibited" >&2; exit 33; }
    [[ -d "$out" && ! -e "$out/dispatches" ]] || { echo "output dispatch state is not fresh; runner dispatch prohibited" >&2; exit 34; }
    set +e
    cd "$dst" && setup_ros && python3 "$dst/experiments/cmr_ros2_compact_cost/runner.py" --binding "$receipt" --kernel-root "$kernel" --output "$out" > "$art/v12_run.log" 2>&1
    rc=$?; printf '%s\n' "$rc" > "$art/v12_run.rc"
    exit "$rc"
    ;;
  *) echo "usage: $0 {clone|guard|prepare|run}" >&2; exit 64 ;;
esac