#!/usr/bin/env bash
set -eo pipefail
art=/mnt/c/Users/Yuhling/.codex/worktrees/v7-audit-dds-regression/preflight_profile_20261023
trap 'rc=$?; printf "%s\n" "$rc" > "$art/recovery_supervisor.rc"' EXIT
src=/tmp/cmr_v12_source_3cd0d16_20261023
out=/tmp/cmr_v12_compact_cost_3cd0d16_20261023_r2
kernel=/mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel
receipt=/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json
test ! -e "$out"
cd "$src"
test "$(git rev-parse HEAD)" = 3cd0d168a8a93f441cd195e6fa9743cb6d213218
test -z "$(git status --porcelain)"
source /opt/ros/humble/setup.bash
source /tmp/ltl_ros2_combo_bd75495/install/setup.bash
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$src/ltl_automaton_execution:$src/ltl_automaton_planner:$src/ltl_automaton_planner_core:$src:$kernel:$PYTHONPATH"
python3 -B - <<'PY' > "$art/recovery_importguard.log" 2>&1
from pathlib import Path
import hashlib,json
from experiments.cmr_ros2_compact_cost import runner
from ltl_automaton_planner_core.ltl_tools import discrete_plan as dp
assert Path(dp.__file__).resolve().is_relative_to(Path.cwd())
assert hashlib.sha256(Path(dp.__file__).read_bytes()).hexdigest()=='556b6925a61ce408a0b42d56da45138fcdf3c7c7655e7850eb17b551996df31b'
assert runner.previous.backend.identity()=='35838cf764a85cd04e3376825d1f807bbb458bb2c39418046bd2f2624abb9cd4'
assert len(runner.source_closure())==77
print(json.dumps(dict(status='PASSED',source=str(Path.cwd()),dp=str(dp.__file__),source_files=77)))
PY
set +e
python3 -B experiments/cmr_ros2_compact_cost/runner.py --prepare --binding "$receipt" --kernel-root "$kernel" --output "$out" > "$art/recovery_prepare.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$art/recovery_prepare.rc"
if (( rc != 0 )); then exit "$rc"; fi
python3 -B experiments/cmr_ros2_compact_cost/runner.py --binding "$receipt" --kernel-root "$kernel" --output "$out" > "$art/recovery_run.log" 2>&1
rc=$?; printf '%s\n' "$rc" > "$art/recovery_run.rc"
exit "$rc"
