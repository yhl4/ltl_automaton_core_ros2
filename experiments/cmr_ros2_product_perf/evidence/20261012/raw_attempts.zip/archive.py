"""Archive all observed artifacts and verify member bytes; no planner imports."""
import hashlib,json,pathlib,shutil,zipfile
repo=pathlib.Path('D:/Robotics/Robotics4LLM/ltl_automaton_core-ros2')
raw=pathlib.Path('//wsl.localhost/Ubuntu-22.04-D/tmp/cmr_product_perf_1c172e1_20261012')
evidence=repo/'experiments/cmr_ros2_product_perf/evidence/20261012'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_bytes())
def write(p,v): p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
report=read(raw/'native_readback.json')
assert report['status']=='PASSED'
for name in ('fixtures.rc','run.rc','wsl.rc','native_reader.rc'):
    assert (raw/name).read_text().strip()=='0',name
shutil.copyfile(repo/'experiments/cmr_ros2_product_perf/native_readback.py',raw/'native_readback.py')
shutil.copyfile('C:/Users/Yuhling/AppData/Local/Temp/cmr_product_perf_exec.sh',raw/'exec.sh')
shutil.copyfile(__file__,raw/'archive.py')
evidence.mkdir(parents=True,exist_ok=False)
(evidence/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n')
paths=sorted(p for p in raw.rglob('*') if p.is_file())
manifest={str(p.relative_to(raw)).replace('\\','/'):{'size':p.stat().st_size,'sha256':sha(p)} for p in paths}
archive=evidence/'raw_attempts.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,str(p.relative_to(raw)).replace('\\','/'))
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(manifest)
    for name,value in manifest.items():
        data=z.read(name)
        assert len(data)==value['size'] and hashlib.sha256(data).hexdigest()==value['sha256'],name
write(evidence/'archive_manifest.json',{'schema':'cmr-product-archive-manifest-v1','members':manifest})
shutil.copyfile(raw/'native_readback.json',evidence/'native_readback.json')
plan=read(raw/'plan.json')
index=dict(schema='cmr-product-evidence-index-v1',status='PASSED',scope=plan['scope'],
    source_head=plan['source_head'],execution_identity=plan['execution_identity'],cells=plan['cells'],
    arms=['reference','current_v5','product_v6'],attempts_per_arm=1,method_workers=27,
    independent_certificate_replays=27,total_build_rounds=report['total_build_rounds'],
    directed_fixtures=report['fixtures']['case_count'],real_product_checks=len(report['fixtures']['real_product_checks']),
    frozen_inputs=55,planner_budget_seconds=180,outer_watchdog_seconds=195,
    formal_campaign=False,provider_calls=0,dds_runs=0,driver_rc=0,wsl_rc=0,native_reader_rc=0,
    archive_members=len(manifest),notes=[
      'Fixed previously selected B/C/D instances and FULL/AP-D/DEP-D, one fresh reference/V5/V6 worker per cell; no method retries.',
      'Only deque FIFO and per-build Buchi successor caching. Full reachable TS, reduction, model and Product rebuilt every round. No cross-round cache.',
      'Qualified compiled monitor returns deterministic successors and completes accepting membership before Product construction; arbitrary stateful callbacks are outside scope.',
      'All objectives and original independent persisted certificate replays pass; every V5/V6 scientific round field and target/heap decision agrees apart from backend metadata and time.',
      'Measurements are one attempt per arm/cell. Report every cell including slower complete methods; no pooled or stable speed claims.',
      'Original budgets, INITIAL_LABEL_V1, Fraction costs, gamma10, P2c/P2e/verifier, source authority, tracemalloc and terminal delivery remain.',
      'Prior qualifications, production planner and 55 frozen inputs unchanged; no formal campaign, DDS, providers or historical suite reruns.'])
index['files']={p.name:{'size':p.stat().st_size,'sha256':sha(p)} for p in (archive,evidence/'archive_manifest.json',evidence/'native_readback.json')}
write(evidence/'index.json',index)
print(json.dumps({'archive':index['files']['raw_attempts.zip'],'members':len(manifest),'rounds':report['total_build_rounds']}))
