import json
from pathlib import Path
root = Path('/tmp/ltl_cmr_ros2_refinement_dds_33244a5_20261011_fix2')
rows = []
for path in sorted((root / 'dds').glob('*/dds_artifact.json')):
    value = json.loads(path.read_text())
    pids = {'server':value['server_pid'], 'driver':value['driver_pid'], 'worker':value['driver']['result']['worker_pid']}
    rows.append({'request_id':value['request']['request_id'], 'pids':pids, 'alive':{name:Path('/proc',str(pid)).exists() for name,pid in pids.items()}})
assert all(not alive for row in rows for alive in row['alive'].values())
(root / 'process_cleanup.json').write_text(json.dumps({'status':'PASSED','cases':rows}, indent=2)+'\n')
print(json.dumps({'process_cleanup':'PASSED','cases':len(rows)}))