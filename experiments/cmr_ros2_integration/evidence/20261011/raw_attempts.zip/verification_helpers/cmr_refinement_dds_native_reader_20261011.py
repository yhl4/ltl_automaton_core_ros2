import hashlib
import json
from fractions import Fraction
from pathlib import Path
import sys

initial_root = Path(sys.argv[1])
watchdog_root = Path(sys.argv[2])
root = Path(sys.argv[3])
def read(relative):
    return json.loads((root / relative).read_text(encoding='utf-8'))
def native(path):
    if path.startswith('/mnt/d/'):
        return Path('D:/' + path[7:])
    if path.startswith('/mnt/c/'):
        return Path('C:/' + path[7:])
    raise ValueError(path)
def digest(path):
    data = path.read_bytes()
    return dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())
runner = read('runner.json')
assert runner['qualification_rc'] == 0 and runner['sources_unchanged']
assert (root / 'qualification.rc').read_text().strip() == (root / 'wsl.rc').read_text().strip() == '0'
assert runner['before'] == runner['after']
for path, expected in runner['after'].items():
    assert digest(native(path)) == expected, path
q = json.loads((initial_root / 'qualification/qualification.json').read_text())
assert q['status'] == 'FAILED' and q['population'] == 'SYNTHETIC_SMOKE'
assert q['error'] == "AssertionError('watchdog did not interrupt/clean the injected blocking search')"
assert q['watchdog']['result']['interrupted_phase'] is None
assert digest(initial_root / 'qualification/qualification.json') == json.loads((watchdog_root / 'runner.json').read_text())['initial_qualification_digest']
c = read('continuation.json')
assert c['status'] == 'PASSED' and c['population'] == 'SYNTHETIC_SMOKE'
prior_continuation = json.loads((watchdog_root / 'continuation.json').read_text())
assert prior_continuation['status'] == 'FAILED' and 'action sequence mismatch' in prior_continuation['error']
assert digest(watchdog_root / 'continuation.json') == runner['prior_continuation_digest']
q['watchdog'], q['dds'] = prior_continuation['watchdog'], c['dds']
assert len(q['matrix']) == 6 and len(q['deadline_cases']) == 4

def manifest(m):
    assert len(m['imports']) == 8 and len(m['source_checks']) == 40
    for row in m['imports'].values():
        assert digest(native(row['__file__'])) == dict(size=row['size'], sha256=row['sha256'])
    for row in m['source_checks']:
        assert digest(native(row['path']))['sha256'] == row['actual_sha256'] == row['expected_sha256'] and row['match']
manifest(q['preflight'])

def measured(v):
    assert v['T_total'] == (v['terminal_completion_ns'] - v['method_start_ns']) / 1e9
    assert v['population'] == 'SYNTHETIC_SMOKE'
    if v['terminal_status'] == 'TIMEOUT':
        assert v['right_censored'] and v['timing_status'] == 'RIGHT_CENSORED'
        assert v['objective'] is v['concrete_lasso'] is v['infeasibility_proof'] is None
        assert not v['certificate_valid_for_terminal']
        assert all(not row['terminal_claim_valid'] for row in v['rounds'])
    else:
        assert v['terminal_completion_ns'] < v['deadline_ns'] and not v['right_censored']

def witness(v):
    l = v['concrete_lasso']
    assert l['prefix'][-1] == l['suffix'][0] == l['suffix'][-1]
    assert l['prefix'][0] == [[0, 0], 'q_wait'] and l['suffix_edges']
    assert any(state[1] == 'q_accept' for state in l['suffix'][:-1])
    totals = []
    for part in ('prefix', 'suffix'):
        states, edges = l[part], l[part + '_edges']
        assert len(states) == len(edges) + 1
        total = Fraction(0)
        for source, edge, target in zip(states, edges, states[1:]):
            assert edge['source'] == source and edge['target'] == target
            s, t = source[0], target[0]
            if edge['action'] in ('a_go', 'b_go'):
                assert s[0] == 0 and t == [1, 1 - s[1]]
                cost = Fraction(1 + 3*s[1], 3) + (Fraction(1, 3) if edge['action'] == 'b_go' else 0)
            elif edge['action'] == 'c_return':
                assert s[0] == 1 and t == [0, s[1]]
                cost = Fraction(2, 3)
            else:
                assert edge['action'] == 'd_noise' and t == [s[0], 1-s[1]]
                cost = Fraction(5)
            assert target[1] == ('q_accept' if t[0] else 'q_wait')
            assert Fraction(edge['cost']) == cost
            total += cost
        assert total == Fraction(l[part + '_cost'])
        totals.append(total)
    assert totals[0] + 10*totals[1] == Fraction(v['objective']) == 30

matrix = []
for pair in q['matrix']:
    req = pair['request']
    for key in ('reference', 'adapted'):
        value = pair[key]
        measured(value)
        manifest(value['manifest_preflight'])
        assert value['final_precision'] == [0, 1]
        assert len(value['rounds']) == (2 if req['method'] == 'AP-D' else 1)
        assert value['refinement_rounds'] == (1 if req['method'] == 'AP-D' else 0)
        if req['method'] == 'AP-D':
            row = value['rounds'][0]
            assert row['precision'] == [0] and row['refinement']['new_precision'] == [0, 1]
            assert Fraction(row['lower_bound']) == 10
        if req['variant'] == 'cost_gap':
            assert value['terminal_status'] == 'OPTIMALITY_CERTIFIED'
            witness(value)
        else:
            assert value['terminal_status'] == 'INFEASIBLE_CERTIFIED'
            assert value['infeasibility_proof']['type'] == 'REDUCED_PRODUCT_EXACT_EMPTY'
            assert value['objective'] is None
    assert pair['adapted']['worker_exitcode'] == 0 and not pair['adapted']['worker_alive_after_cleanup']
    matrix.append(dict(variant=req['variant'], method=req['method'], status=pair['adapted']['terminal_status'], objective=pair['adapted']['objective'], rounds=len(pair['adapted']['rounds']), T_total=pair['adapted']['T_total']))
for case in q['deadline_cases']:
    measured(case['result'])
    assert case['result']['terminal_status'] == 'TIMEOUT' and case['result']['T_total'] >= 0.1
watchdog = q['watchdog']['result']
measured(watchdog)
assert watchdog['timeout_stage'] == 'outer_watchdog' and watchdog['interrupted_phase'] == 'search'
assert watchdog['T_total'] >= 7 and not watchdog['worker_alive_after_cleanup']
assert q['deadline_boundary_contract']['terminal_status'] == 'TIMEOUT'
assert q['dds']['status'] == 'PASSED' and len(q['dds']['cases']) == 3
dds = []
for case, domain in zip(q['dds']['cases'], (216, 217, 218)):
    value = read('dds/' + case['request_id'] + '/dds_artifact.json')
    assert value['domain_id'] == domain and value['validation_status'] == 'PASSED'
    assert value['server_rc'] == value['driver_rc'] == 0
    driver, server = value['driver'], value['server']
    result = driver['result']
    measured(result)
    assert not result['worker_alive_after_cleanup'] and result['worker_exitcode'] == 0
    assert len({value['server_pid'], value['driver_pid'], result['worker_pid']}) == 3
    assert driver['module_identity_match']
    for name, path in driver['module_paths'].items():
        assert digest(native(driver['module_resolved_paths'][name]))['sha256'] == driver['module_sha256'][name]
    names = [event['event'] for event in server['events']]
    order = ['request_received', 'cmr_solver_started', 'cmr_solver_completed', 'result_published']
    assert all(names.count(name) == 1 for name in order)
    assert [names.index(name) for name in order] == sorted(names.index(name) for name in order)
    if result['terminal_status'] == 'OPTIMALITY_CERTIFIED':
        manifest(result['manifest_preflight'])
        witness(result)
        edges = result['concrete_lasso']['prefix_edges'] + result['concrete_lasso']['suffix_edges']
        assert driver['commands'] == [edge['action'] for edge in edges]
        assert driver['completion_count'] == driver['observer_feedback_count'] == driver['abstraction_feedback_count'] == len(edges)
        targets = [[str(component) for component in edge['target'][0]] for edge in edges]
        assert driver['observed_ts_states'] == driver['observer_feedback_states'] == targets
    else:
        assert not driver['commands'] and driver['completion_count'] == driver['observer_feedback_count'] == 0
    dds.append(dict(request_id=case['request_id'], domain=domain, status=result['terminal_status'], actions=driver['commands'], T_total=result['T_total']))
summary = dict(schema='cmr-ros2-native-readback-v1', status='PASSED', planner_imported=False, frozen_inputs=len(runner['after']), source_maps=40, unique_scientific_sources=20, actual_cmr_ros_imports=8, matrix=matrix, injected_timeouts=[dict(stage=c['request']['fault_stage'], variant=c['request']['variant'], T_total=c['result']['T_total']) for c in q['deadline_cases']], watchdog_seconds=watchdog['T_total'], watchdog_worker_exitcode=watchdog['worker_exitcode'], dds=dds)
(root / 'native_readback.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))