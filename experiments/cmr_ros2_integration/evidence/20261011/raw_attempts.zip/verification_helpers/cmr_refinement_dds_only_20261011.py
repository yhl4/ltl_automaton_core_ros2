def main():
    import hashlib
    import json
    from pathlib import Path
    import sys
    import time
    import traceback
    repo = Path('/mnt/d/Robotics/Robotics4LLM/ltl_automaton_core-ros2')
    prior_root = Path('/tmp/ltl_cmr_ros2_refinement_dds_33244a5_20261011_fix1')
    work = Path('/tmp/ltl_cmr_ros2_refinement_dds_33244a5_20261011_fix2')
    work.mkdir(exist_ok=False)
    def digest(path):
        data = Path(path).read_bytes()
        return dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())
    prior = json.loads((prior_root / 'runner.json').read_text())
    paths = list(prior['after'])
    for path, expected in prior['after'].items():
        if not path.endswith('/cmr_ros2_integration/dds_smoke.py'):
            assert digest(path) == expected, path
    metadata = dict(schema='cmr-ros2-dds-continuation-runner-v1', source_head=prior['source_head'], prior_continuation=str(prior_root / 'continuation.json'), prior_continuation_digest=digest(prior_root / 'continuation.json'), changed_input_only='experiments/cmr_ros2_integration/dds_smoke.py stale injection after accepted dispatch and import resolved paths', scope='SYNTHETIC_SMOKE_ONLY_DDS', before={path: digest(path) for path in paths}, start_ns=time.time_ns())
    (work / 'runner.json').write_text(json.dumps(metadata, indent=2))
    sys.path.insert(0, str(repo / 'experiments/cmr_ros2_integration'))
    import runtime
    from dds_smoke import run_dds_smoke
    binding = '/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json'
    kernel = '/mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel'
    artifact = dict(schema='cmr-ros2-dds-continuation-v1', status='RUNNING', population='SYNTHETIC_SMOKE', prior_continuation=metadata['prior_continuation'], prior_continuation_digest=metadata['prior_continuation_digest'])
    rc = 1
    try:
        artifact['dds'] = run_dds_smoke(binding, kernel, work / 'dds')
        assert artifact['dds']['status'] == 'PASSED'
        artifact['status'] = 'PASSED'
        rc = 0
    except Exception as error:
        artifact.update(status='FAILED', error=repr(error), traceback=traceback.format_exc())
        traceback.print_exc()
    finally:
        runtime.write_json(work / 'continuation.json', artifact)
        (work / 'qualification.rc').write_text(str(rc) + '\n')
        metadata.update(after={path: digest(path) for path in paths}, qualification_rc=rc, completion_ns=time.time_ns())
        metadata['sources_unchanged'] = metadata['before'] == metadata['after']
        (work / 'runner.json').write_text(json.dumps(metadata, indent=2))
        assert metadata['sources_unchanged']
    print(json.dumps(dict(output=str(work), rc=rc, sources_unchanged=metadata['sources_unchanged'])))
    raise SystemExit(rc)

if __name__ == '__main__':
    main()