import ast
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

repo = Path('/mnt/d/Robotics/Robotics4LLM/ltl_automaton_core-ros2')
work = Path('/tmp/ltl_cmr_ros2_refinement_dds_33244a5_20261011')
work.mkdir(exist_ok=False)
head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
assert head == '33244a5bc5ed9c63184f1ae9c7c5ad5b52334bfa', head
base = json.loads(Path('/tmp/ltl_replan_type_tuple_regression_fa9c990/expected_inputs.json').read_text())
def digest(path):
    value = Path(path).read_bytes()
    return {'sha256': hashlib.sha256(value).hexdigest(), 'size': len(value)}
for path, expected in base.items():
    assert digest(path) == expected, path
paths = list(base)
paths.extend(str(repo / 'experiments/cmr_ros2_smoke' / name) for name in ('backend.py', 'smoke.py', 'README.md'))
paths.extend(str(repo / 'experiments/cmr_ros2_integration' / name) for name in ('runtime.py', 'verify_smoke.py', 'dds_smoke.py', 'README.md'))
paths.extend(str(repo / 'ltl_automaton_execution/ltl_automaton_execution' / name) for name in ('execution_node.py', 'execution.py', 'fake_runtime.py', 'models.py', 'accepted_run_resolver.py'))
paths.extend(str(path) for path in sorted((repo / 'ltl_automaton_msgs/msg').glob('*.msg')))
paths.append(str(repo / 'ltl_automaton_msgs/srv/GetPlanningGraphSnapshot.srv'))
paths.extend(('/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json', '/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_ltl_v2_core_r2_binding_20261002/execution_binding.json'))
before = {path: digest(path) for path in paths}
for name in ('runtime.py', 'verify_smoke.py', 'dds_smoke.py'):
    ast.parse((repo / 'experiments/cmr_ros2_integration' / name).read_text())
import networkx
import rclpy
assert networkx.__version__ == '2.4'
metadata = dict(schema='cmr-ros2-isolated-runner-v1', source_head=head, python=platform.python_version(), networkx=networkx.__version__, rmw=rclpy.utilities.get_rmw_implementation_identifier(), ros_distro=os.environ.get('ROS_DISTRO'), scope='SYNTHETIC_SMOKE_ONLY', before=before, start_ns=time.time_ns())
(work / 'runner.json').write_text(json.dumps(metadata, indent=2))
command = [sys.executable, '-B', str(repo / 'experiments/cmr_ros2_integration/verify_smoke.py'), '--binding', '/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json', '--kernel-root', '/mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel', '--output', str(work / 'qualification')]
with (work / 'stdout.txt').open('w') as out, (work / 'stderr.txt').open('w') as err:
    result = subprocess.run(command, stdout=out, stderr=err)
(work / 'qualification.rc').write_text(str(result.returncode) + '\n')
metadata.update(after={path: digest(path) for path in paths}, qualification_rc=result.returncode, completion_ns=time.time_ns())
metadata['sources_unchanged'] = metadata['before'] == metadata['after']
(work / 'runner.json').write_text(json.dumps(metadata, indent=2))
print(json.dumps(dict(output=str(work), rc=result.returncode, sources_unchanged=metadata['sources_unchanged'])))
assert metadata['sources_unchanged']
raise SystemExit(result.returncode)