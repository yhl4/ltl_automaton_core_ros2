#!/usr/bin/env bash
set -eo pipefail
log=/mnt/c/Users/Yuhling/.codex/worktrees/v7-audit-dds-regression/v10_suffix_reuse_20261022
repository=/mnt/d/Robotics/Robotics4LLM/ltl_automaton_core-ros2
src=/tmp/cmr_v10_source_7a3ddc1_20261022
out=/tmp/cmr_v10_suffix_reuse_7a3ddc1_20261022
kernel=/mnt/c/Users/Yuhling/.codex/worktrees/cmr-p1b-initial-label/Robotics4LLM/ltl_planning_studio/ecc_p1_formal_kernel
receipt=/mnt/d/Robotics/Robotics4LLM/ltl_planning_studio/analysis/cmr_experiment_a_missing_data_repair_20261004/final_campaign_receipt.json
test ! -e "$src"
test ! -e "$out"
git clone --branch codex/v10-suffix-reuse --single-branch "$repository" "$src" 2>&1 | tee "$log/clone_7a3ddc1.log"
cd "$src"
test "$(git rev-parse HEAD)" = 7a3ddc1d0b8ed22fb75c069085b8ffa3ff357ffc
test -z "$(git status --porcelain)"
source /opt/ros/humble/setup.bash
source /tmp/ltl_ros2_combo_bd75495/install/setup.bash
export PYTHONDONTWRITEBYTECODE=1
export ROS_LOCALHOST_ONLY=1
export PYTHONPATH="$src/ltl_automaton_execution:$src/ltl_automaton_planner:$src/ltl_automaton_planner_core:$src:$kernel:${PYTHONPATH:-}"
python3 -B - <<'PY' 2>&1 | tee "$log/importguard_7a3ddc1.log"
import hashlib,subprocess,sys
from pathlib import Path
from ltl_automaton_planner_core.ltl_tools import discrete_plan as dp
from experiments.cmr_ros2_reduction_reuse.backend import identity
assert Path(dp.__file__).resolve().is_relative_to(Path.cwd())
assert hashlib.sha256(Path(dp.__file__).read_bytes()).hexdigest()=='556b6925a61ce408a0b42d56da45138fcdf3c7c7655e7850eb17b551996df31b'
assert identity()=='f4fb6a2dff6fe4fe881b2909dbeb70b254977fa7c74fa39d06863141cd001259'
print('head',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
print('status',repr(subprocess.check_output(['git','status','--porcelain'],text=True)))
print('discrete_plan',dp.__file__)
print('python',sys.executable)
PY
python3 -B experiments/cmr_ros2_suffix_reuse/runner.py --prepare --binding "$receipt" --kernel-root "$kernel" --output "$out" 2>&1 | tee "$log/prepare_7a3ddc1.log"
python3 -B experiments/cmr_ros2_suffix_reuse/runner.py --binding "$receipt" --kernel-root "$kernel" --output "$out" 2>&1 | tee "$log/run_7a3ddc1.log"
