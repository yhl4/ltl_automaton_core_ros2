"""Native artifact read-back; standard library only, no planner imports."""
import copy
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('D:/Robotics/Robotics4LLM/ltl_automaton_core-ros2')
OUTPUT = Path('//wsl.localhost/Ubuntu-22.04-D/tmp/cmr_bfull_compact_0f54c05_20261012')


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def native(value):
    if value.startswith('/mnt/'):
        return Path(value[5].upper() + ':/' + value[7:])
    return Path(value)


def checked(condition, message):
    if not condition:
        raise AssertionError(message)


def check_lasso(lasso, accepting, objective, supplied_costs=None):
    costs = {}
    for group in ('prefix', 'suffix'):
        states, edges = lasso[group], lasso[group + '_edges']
        checked(len(states) == len(edges) + 1, group + ' structure')
        for source, edge, target in zip(states, edges, states[1:]):
            checked(edge['source'] == source and edge['target'] == target, 'edge adjacency')
        costs[group] = sum((Fraction(e['cost']) for e in edges), Fraction(0))
        stated = (supplied_costs or lasso)[group + '_cost']
        checked(costs[group] == Fraction(stated), group + ' exact cost')
    checked(lasso['suffix_edges'] and lasso['suffix'][0] == lasso['suffix'][-1], 'nonempty closed suffix')
    checked(lasso['prefix'][-1] == lasso['suffix'][0], 'entry identity')
    checked(any((s['buchi_state'] if isinstance(s, dict) else s[1]) in accepting
                for s in lasso['suffix']), 'acceptance')
    checked(costs['prefix'] + 10 * costs['suffix'] == Fraction(objective), 'objective')


def main():
    plan = read(OUTPUT / 'plan.json')
    checked(plan['arms'] == ['reference', 'baseline', 'optimized'] and plan['attempts_per_arm'] == 1, 'one triple')
    checked(plan['planner_budget_seconds'] == 180 and plan['outer_watchdog_seconds'] == 195, 'budgets')
    checked(plan['instance_id'] == 'B-D-BRANCH-S1' and plan['method'] == 'FULL', 'scope')
    for name, expected in plan['source_closure'].items():
        checked(digest(ROOT / name) == expected, 'source closure')
        checked(digest(OUTPUT / 'frozen_adapter' / name) == expected, 'frozen source bytes')
    before, after = (read(OUTPUT / ('frozen_inputs_' + when + '.json')) for when in ('before', 'after'))
    checked(before == after and len(before) == 55, 'frozen inputs before/after')
    for name, expected in before.items():
        actual = native(name)
        checked(actual.stat().st_size == expected['size'] and digest(actual) == expected['sha256'], 'qualified input bytes')
    fixture = read(OUTPUT / 'fixtures.json')
    checked(fixture['status'] == 'PASSED' and len(fixture['cases']) == 13, 'fixed fixtures')
    checked(fixture['cases']['first_bound_is_loose']['work']['exact_entry_searches'] == 2, 'loose bound continuation')
    comparison = read(OUTPUT / 'comparison.json')
    checked(comparison['status'] == 'PASSED' and comparison['plan'] == plan, 'completed comparison')
    rows, summary = {}, []
    source_schemas = None
    for arm in plan['arms']:
        directory = OUTPUT / arm
        value = read(directory / 'result.json')
        checked(comparison['arms'][arm] == value, 'report/result identical')
        row = value['row']
        rows[arm] = row
        if arm == 'baseline':
            checked(row['backend_id'] == plan['baseline_backend'], 'qualified V2 backend')
        elif arm == 'optimized':
            checked(row['backend_id'] == plan['candidate_backend'], 'compact V3 backend')
        checked(value['worker_exitcode'] == 0 and not value['worker_alive_after_cleanup'], 'worker cleanup')
        checked((directory / 'worker.rc').read_text().strip() == '0', 'worker rc')
        checked(row['terminal_status'] == 'OPTIMALITY_CERTIFIED' and not row['right_censored'], 'certified terminal')
        checked(row['certificate_valid_for_terminal'] and row['certificate_verifier_status'] == 'PASS', 'certificate authority')
        checked(row['T_total'] == (row['terminal_completion_ns'] - row['method_start_ns']) / 1e9 and row['T_total'] < 180, 'measured total')
        checked(row['planner_budget_seconds'] == 180 and row['outer_watchdog_seconds'] == 195, 'row budgets')
        unhashed = dict(row)
        expected = unhashed.pop('result_hash')
        checked(hashlib.sha256(json.dumps(unhashed, sort_keys=True, ensure_ascii=False,
                separators=(',', ':')).encode()).hexdigest() == expected, 'row hash')
        checked(comparison['certificate_replays'][arm]['status'] == 'PASS', 'independent replay')
        cert_path = directory / 'certificates' / row['certificate_path']
        checked(digest(cert_path) == row['certificate_hash'], 'persisted certificate hash')
        cert = read(cert_path)
        checked(cert['execution_commit'] == plan['execution_identity'] and cert['gamma'] == '10', 'certificate version/gamma')
        checked(cert['instance_id'] == plan['instance_id'] and cert['method'] == 'FULL', 'certificate cell')
        check_lasso(cert['full_model_lasso'], cert['accepting_buchi_states'], row['objective'], cert)
        check_lasso(value['transport']['concrete_lasso'], value['transport']['accepting_buchi_states'], row['objective'])
        manifest = read(directory / 'preflight.json')
        checked(len(manifest['source_checks']) == 40, '40 scientific source rows')
        for item in manifest['source_checks']:
            checked(item['match'] and item['actual_sha256'] == item['expected_sha256'] == digest(native(item['path'])), 'science hash')
        for key in ('imports', 'runner_imports'):
            checked(len(manifest[key]) == (8 if key == 'imports' else 6), 'actual import count')
            for item in manifest[key].values():
                checked(item['__file__'] == item['expected_path'] and item['sha256'] == item['expected_sha256'] == digest(native(item['__file__'])), 'actual import bytes')
        checked(manifest['bound_runner']['other_ast_unchanged'], 'runner AST transform')
        config = value['backend_configuration']
        checked(config['original_loop_code_preserved'] and config['original_local_code_preserved'], 'runner code unchanged')
        checked(config['backend_id'] == row['backend_id'] and config['backend_sha256'] == row['backend_sha256'], 'backend metadata')
        schemas = read(directory / 'schema_binding.json')['schemas']
        normalized = copy.deepcopy(schemas)
        for schema in normalized.values():
            checked(schema['properties']['backend_sha256']['const'] == row['backend_sha256'], 'schema identity')
            schema.pop('$id')
            schema['properties']['backend_sha256'].pop('const')
        if source_schemas is None:
            source_schemas = normalized
        checked(normalized == source_schemas, 'only backend SHA and schema ID change')
        round_row = row['rounds'][0]
        checked(len(row['rounds']) == 1 and round_row['product_unique_states'] == 512 and round_row['product_unique_edges'] == 5808, 'same Product')
        if arm == 'optimized':
            work = value['search_work'][0]
            checked(work['tracemalloc_enabled'] and work['completed'] and not work['deadline_observed_exceeded'], 'instrumentation retained')
            checked(work['candidate_entries'] == work['exact_entry_searches'] + work['bound_pruned_entries'], 'entry accounting')
            for phase in ('prefix', 'lower_bound', 'suffix'):
                checked(work[phase + '_settled'] == sum(h['returned_len'] for h in work['helpers'] if h['phase'] == phase), 'phase accounting')
        summary.append(dict(arm=arm, T_total=row['T_total'], T_search=row['T_search'], objective=row['objective'],
              rounds=len(row['rounds']), **{k: round_row[k] for k in ('candidate_entries', 'exact_entry_searches', 'bound_pruned_entries',
              'queue_pushes', 'queue_pops', 'prefix_settled', 'lower_bound_settled', 'suffix_settled')}))
    checked(all(Fraction(r['objective']) == Fraction(rows['reference']['objective']) and r['initial_S0'] == rows['reference']['initial_S0'] for r in rows.values()), 'exact paired outcomes/precision')
    report = dict(schema='cmr-bfull-compact-native-readback-v1', status='PASSED', planner_imported=False,
                  frozen_inputs=55, fixtures=13, workers=3, independent_certificate_replays=3, arms=summary,
                  total_ratio_baseline_over_optimized=rows['baseline']['T_total'] / rows['optimized']['T_total'],
                  search_ratio_baseline_over_optimized=rows['baseline']['T_search'] / rows['optimized']['T_search'])
    (OUTPUT / 'native_readback.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
